<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 

include('header.php');
?>
  
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-6" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h3 class="font-28 text-white">NSS FAQ</h2>
            </div>
          </div>
        </div>
      </div>      
    </section>

    <section>
      <div class="container">
                     
              
                  <div class="row">
                  
				   <section>
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2">
            <div id="accordion1" class="panel-group accordion">
              <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion11" class="active" aria-expanded="true"> <span class="open-sub"></span> <strong>Q. When is the NSS day observed ?</strong></a> </div>
                <div id="accordion11" class="panel-collapse collapse in" role="tablist" aria-expanded="true">
                  <div class="panel-content">
                    <p>The NSS day is observed on 24th September every year.</p>
                  </div>
                </div>
              </div>
              <div class="panel">
                <div class="panel-title"> <a class="collapsed" data-parent="#accordion1" data-toggle="collapse" href="#accordion12" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.How can i join NSS? </strong></a> </div>
                <div id="accordion12" class="panel-collapse collapse" role="tablist" aria-expanded="false" style="height: 0px;">
                  <div class="panel-content">
                   <p>Simply by enrolling/registering yourself in NSS unit through the Programme Officer concerned </p>
                  </div>
                </div>
              </div>
              <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion13" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.I am a graduate and still very keen to be a part of NSS. How can I continue my association with NSS ? </strong></a> </div>
                <div id="accordion13" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>You can join an NSS open unit.</p>
                  </div>
                </div>
              </div>
              <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion14" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.What is the uniform in NSS ? </strong></a> </div>
                <div id="accordion14" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>There is no uniform prescribed for NSS volunteers.</p>
                  </div>
                </div>
              </div>
              <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion15" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.What sorts of benefit I can get from this scheme? </strong></a> </div>
                <div id="accordion15" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>You can get some weightage during admissions in higher studies and other benefits as decided by the institutions/university. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion16" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.Will I get some additional weightage during my admission in higher studies ? </strong></a> </div>
                <div id="accordion16" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>Yes we can get additional weightage as decided by the Institution. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion17" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.What is meant by community service? </strong></a> </div>
                <div id="accordion17" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>Services rendered by the NSS volunteers in the community. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion18" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.What is an adopted village/slum ?  </strong></a> </div>
                <div id="accordion18" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>Generally an NSS unit adopts nearby village where certain projects are run by the NSS volunteers for the development of village. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion19" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.What contribution has NSS given against the devil of AIDS ? </strong></a> </div>
                <div id="accordion19" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>NSS has created awareness among students & masses by means of AIDS awareness rallies, seminars meeting & Quiz contests etc. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion20" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.Are we supposed to pay any fees for enrolment as an NSS volunteer? </strong></a> </div>
                <div id="accordion20" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>No, NSS is a centrally sponsored scheme.</p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion21" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.What does the colour Navy blue depict in NSS badge? </strong></a> </div>
                <div id="accordion21" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>The navy blue colour indicates the cosmos of which the NSS is a tiny part , ready to contribute its share for the welfare of the mankind. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion22" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.What does the colour red depicts in NSS badge? </strong></a> </div>
                <div id="accordion22" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>The Red colour in the badge indicates that the NSS volunteers are full of blood i.e. lively, active, energetic and full of high spirit. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion23" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.How can I participate in Republic Day parade camp at Rajpath in New Delhi? </strong></a> </div>
                <div id="accordion23" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>You will have to get through the NSS Pre-Republic Day Parade Camp. You must have a good physical health and measurements as prescribed by the Ministry of Youth Affairs & Sports. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion24" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.What is Inter State Youth Exchange programme? </strong></a> </div>
                <div id="accordion24" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>It is the programme sponsored by the Ministry where NSS volunteers of one state visit another state to get acquainted with customs and tradition of other states. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion25" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.Is there any certain academic qualification required for enrolment as NSS volunteers? </strong></a> </div>
                <div id="accordion25" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p> A student can join NSS at +1 stage (school) at college level.</p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion26" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.Will I get some extra days for preparation of my exams in lieu of the month & ten days time devoted by me in the NSS Pre-R.D. and R.D. camps? </strong></a> </div>
                <div id="accordion26" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>No, You will have to manage it at your own.</p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion27" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.Should an NSS unit work in such areas where political conflicts are likely to arise? </strong></a> </div>
                <div id="accordion27" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>NSS units should avoid such areas where political conflicts are likely to arise. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion28" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.What does the giant wheel depicts in NSS symbol? </strong></a> </div>
                <div id="accordion28" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>The giant wheels of the Sun Temple portray the cycle of creation ,preservation and release, and signify the movement in life across time and space. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion29" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.Where is the NSS Headquarter located? </strong></a> </div>
                <div id="accordion29" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>The NSS Headquarter is located in New Delhi. </p>
                  </div>
                </div>
              </div>
			   <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion30" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.Who is the National Head controlling this scheme?</strong></a> </div>
                <div id="accordion30" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p> The Programme Adviser, NSS is the National Head controlling this scheme.</p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion31" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.he Programme Adviser, NSS is the National Head controlling this scheme.
</strong></a> </div>
                <div id="accordion31" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>No, the NSS scheme starts from 11th Standard onwards, however the Govt. of India has some plan to introduce this scheme from the 9th Standard. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion32" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.How much time I will have to devote as an NSS volunteer?</strong></a> </div>
                <div id="accordion32" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>Total 240 hours social service in two years duration </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion33" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.If I complete only 120 hrs social service in NSS, will I get any certificate?</strong></a> </div>
                <div id="accordion33" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>You will get only certificate for completing one year social service under the aegis of NSS by your institution. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion34" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.Can I get any chance for visiting other States in the country or abroad? How?</strong></a> </div>
                <div id="accordion34" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p>Yes you can get several chances for visiting other States/abroad through Youth Exchange programmes. </p>
                  </div>
                </div>
              </div>
			  <div class="panel">
                <div class="panel-title"> <a data-parent="#accordion1" data-toggle="collapse" href="#accordion35" class="collapsed" aria-expanded="false"> <span class="open-sub"></span> <strong>Q.I have heard about NYKS, what is the difference between NSS & NYKS?</strong></a> </div>
                <div id="accordion35" class="panel-collapse collapse" role="tablist" aria-expanded="false">
                  <div class="panel-content">
                    <p> NYKS stands for Nehru Yuva Kendra Sangathan. NYKs basically deals with rural youth and NSS with student youth.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
            </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->

  
   <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>