<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />
<style>
* {
    box-sizing: border-box;
}

.columns {
    float: left;
    width: 50%;
    padding: 8px;
}

.price {
    list-style-type: none;
    border: 1px solid #eee;
    margin: 0;
    padding: 0;
    -webkit-transition: 0.3s;
    transition: 0.3s;
}

.price:hover {
    box-shadow: 0 8px 12px 0 rgba(255,153,51,2)
}

.price .header {
    background-color:  green;
    color: white;
    font-size: 25px;
}

.price li {
    border-bottom: 1px solid #eee;
    padding: 20px;
    text-align: center;
}

.price .grey {
    background-color: #eee;
    font-size: 20px;
}

.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 10px 25px;
    text-align: center;
    text-decoration: none;
    font-size: 18px;
}

@media only screen and (max-width: 600px) {
    .columns {
        width: 100%;
    }
}
.scroll{
    height:400px;
    overflow:none;
}

</style>


<!-- Page Title -->
<title>National Service Scheme</title>



<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 

include('header.php');
?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-6" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h3 class="font-28 text-white">NSS DIRECTORY</h2>
              
            </div>
          </div>
        </div>
      </div>      
    </section>

    <section>
      <div class="container">
     <div class="columns , scroll">
  <ul class="price , scroll" style="overflow:scroll">
    <li class="header">Regional centres</li>
      <li>chandigarh</li>
	  <li>delhi</li>
	  <li>lucknow</li>
	  <li>jaipur</li>
	  <li>patna</li>
	  <li>Guvahati</li>
	  <li>Ahmedabad</li>
	  <li>Bhopal</li>
      <li>Calcutta</li>
	  <li>pune</li>
	  <li>Bhubaneswar</li>
	  <li>Hyderabad</li>
	  <li>Bangalore</li>
	  <li>Chennai</li>
	  <li>Trivandrum</li>
	  </ul>
</div>

<div class="columns , scroll">
  <ul class="price , scroll" style="overflow:scroll">
    <li class="header">Training and Orientation Centres(TOC)</li>
      <li>patiala</li>
	  <li>lucknow</li>
	  <li>ujjain</li>
	  <li>jaipur</li>
	  <li>Bhubaneswar</li>
	  <li>Coimbatore</li>
	  <li>kharagpur</li>
	  <li>hyderabad</li>
	  
  </ul>
</div>

<div class="columns , scroll">
  <ul class="price , scroll" style="overflow:scroll">
    <li class="header">TORC</li>
      <li>chandigarh</li>
	  <li>delhi</li>
	  <li>calcutta</li>
	  <li>Mumbai</li>
	  
  </ul>
</div>
<div class="columns , scroll">
  <ul class="price , scroll" style="overflow:scroll">
    <li class="header">State and Union Territories</li>
    <li>Jammu & Kashmir</li>
	<li>Punjab</li>
	<li>Himachal Pradesh</li>
	<li>Delhi</li>
	<li>Rajasthan</li>
	<li>Sikkim</li>
	<li>Assam</li>
	<li>Tripura</li>
	<li>Nagaland</li>
	<li>Bihar</li>
	<li>Jharkhand</li>
	<li>Chattisgarh</li>
	<li>Madhya Pradesh</li>
	<li>Gujarat</li>
    <li>Goa</li>
	<li>Karnataka</li>
	<li>Maharashtra</li>
    <li>Meghalaya</li>
    <li>kerala</li>
    <li>Manipur</li>
	<li>Tamil Nadu</li>
  </ul>
</div>
                
              
                 
      
      </div>
    </section>
  </div>
  <!-- end main-content -->

  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>