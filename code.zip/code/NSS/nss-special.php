<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 

include('header.php');
?>
  
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: home -->
    <section id="home" class="divider parallax" data-stellar-background-ratio="0.5">
      <div class="maximage-slider">
        <div id="maximage">
          <img src="images/bg/bg666.jpg" alt=""/>
        </div>
        <div class="fullscreen-controls"> <a class="img-prev"><i class="pe-7s-angle-left"></i></a> <a class="img-next"><i class="pe-7s-angle-right"></i></a> </div>
      </div>
      <div class="display-table">
        <div class="display-table-cell">
          <div class="container pt-150 pb-150">
            <div class="row">
              <div class="col-md-8 col-md-offset-2 text-center">
                <div class="inline-block outline-border mt-40 pb-60 pl-60 pr-60 pt-40" data-bg-color="rgba(255,255,255, 0.8)">
                  <h1 style="color:orange;" > Special Camping Programme</h1>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <!-- Section: About -->
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
		  <h3 class="text-theme-colored">Introduction</h3>
            <p class="textjustify">Special Camping forms an integral part of National Service Scheme. It has special appeal to the youth as it provides unique opportunities to the students for group living, collective experience sharing and constant interaction with community..</p>
			<p class="textjustify">Special campings are organised generally on various developmental issues of national importance. In the past the themes of the Special Camping Programmes have been 'Youth Against Famine', 'Youth Against Dirt and Disease', 'Youth for Rural Reconstruction', 'Youth for Eco-Development' and 'Youth for Mass Literacy', 'Youth for National Integration & Social Harmony'. The current theme of Special Camp is 'Youth for Sustainable Development with special focus on Watershed Management and Wasteland Development. Every year 50 percent of the volunteers of each NSS unit are expected to participate in special camps which is of seven days duration..</p>
            <h3 class="text-theme-colored">Contributions of Special Camping Programme</h3>
			<p class="textjustify">Concerted efforts have to be made for a number of years for reconstruction activities in rural areas and urban slums for improving the living conditions of economically and socially weaker sections of the community. For this, the universities colleges land +2 institutions having NSS have a special role to play in collaboration with other Departments and local authorities engaged in Development work. They should adopt a village or group of villages/urban slums for intensive social development, where special camps are organised by them year after year to create tangible and durable community assets.</p>
			</table></table>
			<h3 class="text-theme-colored">Objectives of the Special Camping programme</h3>
			<p class="textjustify"> The primary objectives of the special camping programmes are:-</p>
            <ul class="list theme-colored check ml-30 pt-10">
                <li class="textjustify">Making education more relevant to the present situation to meet the felt needs of the communities and supplement the education of university/college/school students by bringing them face to face with the community situation..</li>
                <li class="textjustify"> To provide opportunities to students to play their due roles in the implementation of various development "programmes by planning and executing development projects, which not only help in creating durable community assets in rural areas and slums but also result in improvement of the condition of weaker sections of the communities.</li>
                <li class="textjustify"> Encouraging the students and non-students youth to work along with the adults in rural areas, thereby developing their character, social consciousness and commitment, discipline ad healthy and helpful attitudes towards the community:.</li>
                <li class="textjustify">      Building up potential youth leaders by exploring the latent potential among the campers, both students as well as local youth (rural and urban), with a view to involve them more intimately in development projects for longer periods. The local leadership generated during the camps would also be useful in ensuring proper maintenance of the assets created as a result of the camps..</li>
                <li class="textjustify">     Emphasizing the dignity of labour and self-help and the need for combining physical work with intellectual pursuits, and.</li>
                <li class="textjustify">  Encouraging youth to participate enthusiastically in the process of national development, and promote national integration through democratic living and cooperative action..</li>
              </ul>
			  <h3 class="text-theme-colored">Suggestive list of activities during Regular as well as Special Camping</h3>
		    <p class="textjustify">The aim of the Regular and special Camping Programme is to bring youth face to face with the community and make efforts to improve their life. The NSS volunteers are to devote about 80 hours in Regular Activities for the development of the adopted village. Special Camping has been conceived as an opportunity to live with that community for 7 days, and experience the conditions and problems of the people. The NSS volunteers need to be inspired to take initiatives for the improvement of their condition.<br> <span style="color:#3DB4D9;font-weight:bold;">Although the focus of the Special Camps change periodically and regular programmes are organized in response to the community needs at the micro-level, some broad areas of activities are enumerated below:-</span></p>
		    <h4 style="color:red;font-weight:bold";>Environment Enrichment and Conservation: </h4>
	        <p class="textjustify">  Whereas the main theme for the special camping programme would be "Youth for Sustainable Development", activities aimed at environment - enrichment would be organized under the sub-theme of" Youth for Better Environment". The activities under this sub-theme would inter-alia, include:</p>	
		   <ul class="list theme-colored check ml-30 pt-10">
                <li class="textjustify">Plantation of trees, their preservation and upkeep (each NSS unit should plant and protect at least 1000 saplings).</li>
                <li class="textjustify"> Creation of NSS parks/gardens, Tarun Treveni Vanas.  .</li>
                <li class="textjustify">Construction & maintenance of village streets, drains, etc. so as to keep the environment clean;.</li>
                <li class="textjustify">Construction of sanitary latrines etc..</li>
                <li class="textjustify"> Cleaning of village ponds and wells;.</li>
                <li class="textjustify">Environmental sanitation and disposal of garbage & composting;.</li>
				<li class="textjustify">  Prevention of soil erosion, and work for soil conservation,.</li>
				<li class="textjustify"> Watershed management and wasteland development.</li>
				<li class="textjustify"> Preservation and upkeep of monuments, and creation of consciousness about the preservation of cultural heritage among the community..</li>
				<li class="textjustify"> Popularization and construction of Gobar Gas Plants, use of non-conventional energy; .</li>
              </ul>
			  
			  <h4 style="color:red;font-weight:bold";>Health, Family Welfare and Nutrition Programme:</h4>
		     <ul class="list theme-colored check ml-30 pt-10">
                <li class="textjustify">Programme of mass immunization.</li>
                <li class="textjustify">Working with people in nutrition programmes with the help of Home Science and medical college students.</li>
                <li class="textjustify">Provision of safe and clean drinking water;.</li>
                <li class="textjustify">Integrated child development programmes.</li>
                <li class="textjustify">Health education, AIDS Awareness and preliminary health care..</li>
				 <li class="textjustify">Population education and family welfare programme.</li>
				  <li class="textjustify">Life style education centres and counseling centres.</li>
              </ul>
			  <h4 style="color:red;font-weight:bold";>Programmes aimed at creating an awareness for improvement of the status of women:. </h4>
<ul class="list theme-colored check ml-30 pt-10">
                <li class="textjustify">Programmes of educating people and making them aware of women's rights both constitutional and legal.</li>
                <li class="textjustify">Creating consciousness among women that they too contributed to economic and social well-being of the community.</li>
                <li class="textjustify">Creating awareness among women that there is no occupation or vocation which is not open to them provided they acquire the requisite skills.</li>
                <li class="textjustify">Imparting training to women in sewing, embroidery, knitting and other skills wherever possible.</li>
                 </ul>
			  <h4 style="color:red;font-weight:bold";>Social Service Programmes:</h4>
<ul class="list theme-colored check ml-30 pt-10">
<p style="color:#3DB4D9;font-weight:bold;">Depending on the local needs and priorities, the following activities/programmes may be undertaken:-</p>
                <li class="textjustify">Work in hospitals, for example, serving as ward visitors to cheer the patients, help the patients, arranging occupational or hobby activities for long term patients, guidance service for out-door-patients including guiding visitors about hospital's procedures, letter writing and reading for the patients admitted in the hospital; follow up of patients discharged from the hospital by making home visits and places of work, assistance in running dispensaries etc..</li>
                <li class="textjustify">Work with the organisations of child welfare.</li>
                <li class="textjustify">Work in institutions meant for physically and mentally handicapped.</li>
                <li class="textjustify">Organising blood donation, eye pledge programmes.</li>
                <li class="textjustify">Work in Cheshire homes, orphanages, homes for the aged etc. .</li>
                <li class="textjustify">Work in welfare organisations of women.</li>
                <li class="textjustify">Prevention of slums through social education and community action.</li>
        
              </ul>
			  <h4 style="color:red;font-weight:bold";> Production Oriented Programmes: </h4>
<ul class="list theme-colored check ml-30 pt-10">
                <li class="textjustify">Production Oriented Programmes:</li>
                <li class="textjustify">working with people and explaining and teaching improved agricultural practices.</li>
                <li class="textjustify">rodent control land pest control practices.</li>
                <li class="textjustify">weed control.</li>
                <li class="textjustify">soil-testing, soil health care and soil conservation.</li>
                <li class="textjustify">assistance in repair of agriculture machinery.</li>
                <li class="textjustify">work for the promotion and strengthening of cooperative societies in villages.</li>
                <li class="textjustify">assistance and guidance in poultry farming, animal husbandry, care of animal health etc..</li>
                  <li class="textjustify">popularization of small savings.</li>
                <li class="textjustify">assistance in procuring bank loans .</li>
			  </ul>
			  <h4 style="color:red;font-weight:bold";> Relief & Rehabilitation work during Natural Calamities:. </h4>
<ul class="list theme-colored check ml-30 pt-10">
               <p style="color:#3DB4D9;font-weight:bold;">These programme would enable the students to understand and share the agonies of the people affected in the wake of natural calamities like cyclone, flood, earthquakes, etc. The main emphasis should be on their participation in programmes, and working with the people to overcome their handicaps, and assisting the local authorities in relief and rehabilitation work in the wake of natural calamities. The NSS students can be involved in:-</p>
                <li class="textjustify">assisting the authorities in distribution of rations, medicine, clothes etc..</li>
                <li class="textjustify">assisting the health authorities in inoculation and immunization, supply of medicine etc.</li>
                <li class="textjustify"> working with the local people in reconstruction of their huts, cleaning of wells, building roads etc.</li>
                <li class="textjustify">assisting and working with local authorities in relief and rescue operation.</li>
                <li class="textjustify">collection of clothes and other materials, and sending the same to the affected areas.</li>
            
              </ul>
			  <h4 style="color:red;font-weight:bold";>Education and Recreations:. </h4>
<ul class="list theme-colored check ml-30 pt-10">
<p style="color:#3DB4D9;font-weight:bold;">Activities in this field could include:</p>
                <li class="textjustify"> adult education (short-duration programmes).</li>
                <li class="textjustify"> pre-school education programmes.</li>
                <li class="textjustify">programmes of continuing education of school drop outs, remedial coaching of students from weaker sections.</li>
                <li class="textjustify">work in creches.</li>
                <li class="textjustify">participatory cultural and recreation programmes for the community including the use of mass media for instruction and recreation, programmes of community singing, dancing etc.;.</li>
                <li class="textjustify"> organisation of youth clubs, rural land indigenous sports in collaboration with Nehru Yuva Kendras;.</li>
                <li class="textjustify">programmes including discussions on eradications of social evils like communalism, castism, regionalism, untouchability, drug abuse etc..</li>
                <li class="textjustify">non-formal education for/ural youth.</li>
				   <li class="textjustify">legal literacy, consumer awareness. </li>
              </ul>
			  <p style="color:#3DB4D9;font-weight:bold;">The above is only an illustrative list of the type of activities that can be undertaken, Under the programme it would be open to each NSS Unit to undertake one of these programmes or any other activity which may seem desirable to them according to local needs, The NSS Unit should aim at the integrated development of the area selected for its operation which could be a village or a slum. It has also to be ensured that at least a part of the programme does involve manual work.</p>
			  <p style="color:#3">
			  
		</div>
      </div>
    </section>
  </div>
  <!-- end main-content -->

  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>