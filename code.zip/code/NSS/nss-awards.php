<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 

include('header.php');
?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg1.jpg">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h3 class="font-28 text-white"><b>NSS AWARDS</b></h2>
            </div>
          </div>
        </div>
      </div>      
    </section>

    <section>
      <div class="container">
                     
              
                  <div class="row">
                  <h3 style="color:green;"><b>INTRODUCTION:</b></h3></br>
<p>To recognize the voluntary service rendered by NSS volunteers, Programme Officers, NSS Units and the University NSS Cells, it has been proposed to provide suitable incentives/ awardsunder the scheme.</br></p>
<h3 style="color:green;"><b>NATURE OF AWARDS:</b></br></h3>
<p>Indira Gandhi NSS Award at four levels will be given every year and the details are as follows:</br></p>
<div data-example-id="simple-table" class="bs-example"> <table class="table"><thead> <tr> <th>S.NO</th> <th>CATEGORY</th> <th>NO.OF AWARDS</th> <th>VALUE OF AWARD</th> </tr> </thead> <tbody> <tr> <th scope="row">1</th> <td>university/+2 council</td> <td>1</td> <td>Rs. 3,00,000/-</td> </tr> <tr> <th scope="row">2</th> <td>upcoming university</td> <td>1</td> <td>Rs. 2,00,000/-</td> </tr> <tr> <th scope="row">3</th> <td>programme officer</td> <td>10</td> <td>Rs. 70,000/-</td> </tr> <tr> <th scope="row">4</th> <td>NSS unit</td> <td>10</td> <td>Rs. 1,00,000/-</td> </tr> <tr> <th scope="row">5</th> <td>NSS volunteers</td> <td>30</td> <td>Rs. 50,000/-</td> </tr> </tbody> </table>
              </div>
			  <h3 style="color:green;"><b>ELIGIBILITY FOR THE AWARDS:</b></br></h3>
			  <p>Common eligibility considerations at the University/+2 Council level, Upcoming University, for the Programme Officer, NSS Unit and for the NSS Volunteers are as follows:</br></p>
              <p>(a) The University/ +2 Council, Upcoming University, Programme Officer, NSS Unitand the NSS Volunteers who have been operating NSS programme continuously for the last five years only shall be considered.</br>(b) The institution and the nominees must be very regular and punctual in submitting its programme reports and financial returns.</br>(c) The actual enrollment and special camping targets should have been achieved fully and consistently for at least three years preceding the year in which NSS Award is to be considered.</br>(d) All the NSS Units should have adopted villages/ slums/ localities for all rounddevelopment and total literacy.</br>(e) No Vigilance Case/ enquiries should be pending against the NSS Cell.</br>(f) Under the scheme, each volunteer should contribute 240 hours of community work during a period of two years.</br></p>
		 <p>Special eligibility criteria for each category are as follows.</br>The minimum volunteers’ strength of such institutions should not be less than 1,000.</br></p>
		 <h3 style="color:green;"><b>NSS UNITS AND PROGRAMME OFFICERS:</b></br></h3>
		 <p>(a) Colleges/ Schools where there are more than one NSS Unit, such Units should have achieved their enrollment and camping targets fully and consistently.</br>(b) The Programme Officers for all the NSS Units should have been selected as per NSS guidelines. He or she should have been trained at ETIs(Empanneled Training Institutes) and should have completed a minimum of two years as Programme Officer before consideration for the Awards.</br>(c) The NSS Programme Officer Award will go to that Programme Officer whose Unit has bagged the National NSS Unit Award for the same year.</br></p>
		 <h3 style="color:green;"> <b>NSS VOLUNTEERS:</b></br></h3>
		 <p>A student should have completed a minimum of two years of volunteership in NSS.</br></p>
		 <p>(a) He/she should have participated in at least two Special Camping Programme and at least once in National Programmes like R.D. Parade Camp in Delhi, National Integration Camps, National Motivation Camps, Inter-State Youth Exchange Programmes, etc. sponsored by the Ministry of Youth Affairs and Sports.</b></p>
		 <p>(b) He/she should not be less than 18 years and more than 25 years in age. In case of SC/ST, the upper age limit can be relaxed by 3 years. In other words, the maximum age limit should be 28 years for SC/ST.</br></p>

           
    </section>
  </div>
  <!-- end main-content -->

  
   <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>