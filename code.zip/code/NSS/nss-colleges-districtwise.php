<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
<link rel="stylesheet" href="css/1/styles.css">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="css/1/script.js"></script>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>


<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 

include('header.php');
?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
 <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="images/bg/bg1.jpg">
      <div class="container pt-100 pb-50">
        <!-- Section Content -->
        <div class="section-content pt-100">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">NSS COLLEGES LIST</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container mt-30 mb-30 pt-30 pb-30">
        <div class="row ">
          <div class="col-md-9 pull-right flip sm-pull-none">
            <div class="blog-posts">
              <div class="col-md-12">
                <div class="row list-dashed">
                               
                
                  
                  <article class="post clearfix mb-50 pb-30 bg-lighter">
                    <div class="entry-header">
                      <div class="post-thumb">
                        <iframe width="1000" height="1000" src="nss-col-hyd.html" name="rvr" >
						</iframe>
                      </div>
                    </div>
                    
                  </article>

                </div>
              </div>
              
            </div>
          </div>
          <div class="col-md-3">
            <div class="sidebar sidebar-right mt-sm-30">
              <div class="widget">
                <div id='cssmenu'>
<ul>
   <li class='active'><a href='nss-col-hyd.html' target="rvr"><span>Districts of States</span></a></li>
   <li class='has-sub'><a href='#'><span>Andhra Pradesh</span></a>
      <ul>
         <li><a href='colleges/ap/nss-col-ant.html' target="rvr"><span>Anantapur</span></a></li>
         <li><a href='#'><span>Chittoor</span></a></li>
         <li class='last'><a href='#'><span>East Godavari</span></a></li>
		 <li class='last'><a href='#'><span>Guntur</span></a></li>
		 <li class='last'><a href='#'><span>Krishna	</span></a></li>
      </ul>
   </li>
   <li class='has-sub'><a href='#'><span>Arunachal Pradesh</span></a>
      <ul>
         <li><a href='#'><span>Company</span></a></li>
         <li class='last'><a href='#'><span>Contact</span></a></li>
      </ul>
   </li>
   
<li class='has-sub'><a href='#'><span>Assam</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Bihar</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Chhasttisgarh</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Goa</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Gujarath</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Haryana</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>


<li class='has-sub'><a href='#'><span>Himachal Pradesh</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Jammu & Kashmir</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Jharkhand</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Karnataka</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Kerala</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Madhya Pradesh</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Maharashtra</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Manipur</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Meghalaya</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Mizoram</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Nagaland</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Odisha</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Punjab</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Rajasthan</span></a>
      <ul>
         <li><a href='#'><span>8</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Sikkim</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Tamil Nadu</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Telangana</span></a>
      <ul>
         <li><a href='#'><span>Adilabad</span></a></li>
         <li class='last'><a href='#'><span>Bhadradri Kothagudem</span></a></li>
		  <li><a href='colleges/ts/nss-col-hyd.html' target='rvr'>Hyderabad</a></li>
         <li class='last'><a href='#'><span>Jagtial</span></a></li>
		  <li><a href='#'><span>Jangaon</span></a></li>
         <li class='last'><a href='#'><span>Jayashankar Bhupalpally</span></a></li>
		  <li><a href='#'><span>Jogulamba Gadwal</span></a></li>
         <li class='last'><a href='#'><span>kamareddy</span></a></li>
		  <li><a href='#'><span>Karimnagar</span></a></li>
         <li class='last'><a href='#'><span>Khammam</span></a></li>
		  <li><a href='#'><span>Kumuram Bheem</span></a></li>
         <li class='last'><a href='#'><span>Mahabubabad</span></a></li>
		  <li><a href='#'><span>Mahabubnagar</span></a></li>
         <li class='last'><a href='#'><span>Mancherial</span></a></li>
		  <li><a href='#'><span>Medak</span></a></li>
         <li class='last'><a href='#'><span>Medchal</span></a></li>
		  <li><a href='#'><span>Nagarkurnool</span></a></li>
         <li class='last'><a href='#'><span>Nalgonda</span></a></li>
		  <li><a href='#'><span>Nirmal</span></a></li>
         <li class='last'><a href='#'><span>Nizamabad</span></a></li>
		  <li><a href='#'><span>Peddapalli</span></a></li>
         <li class='last'><a href='#'><span>Rajanna Sircilla</span></a></li>
		  <li><a href='#'><span>Rangareddy</span></a></li>
         <li class='last'><a href='#'><span>Sangareddy</span></a></li>
		  <li><a href='#'><span>Siddipet</span></a></li>
         <li class='last'><a href='#'><span>Suryapet</span></a></li>
		 <li><a href='#'><span>Vikarabad</span></a></li>
         <li class='last'><a href='#'><span>Wanaparthy</span></a></li>
		  <li><a href='#'><span>Warangal</span></a></li>
         <li class='last'><a href='#'><span>Yadadri Bhuvanagiri</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Tripura</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Uttarakhand</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>Uttar Pradesh</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

<li class='has-sub'><a href='#'><span>West Bengal</span></a>
      <ul>
         <li><a href='#'><span>3.1</span></a></li>
         <li class='last'><a href='#'><span>3.2</span></a></li>
      </ul>
</li>

</ul>
</div>
                
              </div>
             
             
              
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content --> 
  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>