<?php include("db-config.php"); ?>
<?php
$dis=isset($_POST['d_id'])?$_POST['d_id']:"";

	$sql = "select * from district_college where districtname='$dis'";
	$res = mysqli_query($con, $sql);
	if(mysqli_num_rows($res) > 0) {
		echo "<option value=''>------- Select --------</option>";
		while($row = mysqli_fetch_object($res)) {
			echo "<option value='".$row->collegename."'>".$row->collegename."</option>";
		}
	}

?>
