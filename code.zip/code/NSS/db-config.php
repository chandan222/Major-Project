<?php
$servername="localhost";
$username="root";
$password="";
$dbname="nss";

$con=mysqli_connect($servername,$username,$password,$dbname);
if(!$con){
    die("unable to connect to host");
}

