<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>


<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 

include('header.php');
?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
 <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="images/bg/bg1.jpg">
      <div class="container pt-100 pb-50">
        <!-- Section Content -->
        <div class="section-content pt-100">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">NSS AWARD WINNERS</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container mt-30 mb-30 pt-30 pb-30">
        <div class="row ">
          <div class="col-md-9 pull-right flip sm-pull-none">
            <div class="blog-posts">
              <div class="col-md-12">
                <div class="row list-dashed">
                               
                
                  
                  <article class="post clearfix mb-50 pb-30 bg-lighter">
                    <div class="entry-header">
                      <div class="post-thumb">
                        <iframe width="1000" height="800" src="x.html" name="rvr" allowfullscreen>
                        </iframe>
                      </div>
                    </div>
                    
                  </article>

                </div>
              </div>
              
            </div>
          </div>
          <div class="col-md-3">
            <div class="sidebar sidebar-right mt-sm-30">
              <div class="widget">
                <h5 class="widget-title line-bottom">Archives</h5>
                <ul class="list-divider list-border list check">
                  <li><a href="awardees/2018-awardees.html" target="rvr">Year 2018 Award Winners</a></li>
				  <li><a href="awardees/2017-awardees.html" target="rvr">Year 2017 Award Winners</a>
     <li><a href="awardees/2016-awardees.html" target="rvr">Year 2016 Award Winners</a></li>
     <li><a href="awardees/2015-awardees.html" target="rvr">Year 2015 Award Winners</a></li>
     <li><a href="awardees/2014-awardees.html" target="rvr">Year 2014 Award Winners</a></li>
     <li><a href="awardees/2013-awardees.html" target="rvr">Year 2013 Award Winners</a></li>
     <li><a href="2012-awardees.html" target="rvr">Year 2012 Award Winners</a></li>
     <li><a href="awardees/2011-awardees.html" target="rvr">Year 2011 Award Winners</a></li>
     <li><a href="awardees/2010-awardees.html" target="rvr">Year 2010 Award Winners</a></li>
     <li><a href="awardees/2009-awardees.html" target="rvr">Year 2009 Award Winners</a></li>
     <li><a href="awardees/2008-awardees.html" target="rvr">Year 2008 Award Winners</a></li>
     <li><a href="awardees/2007-awardees.html" target="rvr">Year 2007 Award Winners</a></li>
     <li><a href="awardees/2006-awardees.html" target="rvr">Year 2006 Award Winners</a></li>
     <li><a href="awardees/2005-awardees.html" target="rvr">Year 2005 Award Winners</a></li>
     <li><a href="awardees/2004-awardees.html" target="rvr">Year 2004 Award Winners</a></li>
	 
             </ul>
              </div>
             
             
              
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content --> 
  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>