<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>


<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 

include('header.php');
?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  <!-- Start main-content -->
 <html dir="ltr" lang="en">
 <head>
 <!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>

 
 </head>
 <body>
 <!-- Section: volunteers -->
    <section>
      <div class="container">
        <div class="section-title">
          <div class="row">
            <div class="col-md-6">
              <h2 class="mt-0 text-uppercase font-28"><span class="text-theme-colored font-weight-400">Padma Vibhushan  awardees for social work</span></h2>
              
             
            </div>
          </div>
        </div>
     <div class="section-content">
          <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/DurgabaiDeshmukh.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Durgabai_Deshmukh" target="_blank">Durgabai Deshmukh</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/GaganvihariLallubhaiMehta1.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Gaganvihari_Lallubhai_Mehta" target="_blank">Gaganvihari Lallubhai Mehta</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/janakidevibajaj2.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Janaki_Devi_Bajaj" target="_blank">janaki devi bajaj</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/MaryClubwalaJadhav4.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Mary_Clubwala_Jadhav" target="_blank">Mary Clubwala Jadhav</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>   
    </div>
    </section>
    <!-- Section: volunteers -->
    <section>
      <div class="container">
        <div class="section-title">
          <div class="row">
            <div class="col-md-6">
              
             
            </div>
          </div>
        </div>
     <div class="section-content">
          <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/NellieSengupta.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Nellie_Sengupta" target="_blank">Nellie Sengupta</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/ValerianGracias1.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Valerian_Gracias" target="_blank">Valerian Gracias</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/1.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Veerendra_Heggade" target="_blank">Veerendra Heggade</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/2.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Nirmala_Joshi" target="_blank">Sister Nirmala</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>   
    </div>
    </section>
   <!-- Section: volunteers -->
    <section>
      <div class="container">
        <div class="section-title">
          <div class="row">
            <div class="col-md-6">
              
             
            </div>
          </div>
        </div>
     <div class="section-content">
          <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/3.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Nirmala_Deshpande" target="_blank">Nirmala Deshpande</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/4.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Mohan_Dharia" target="_blank">Mohan Dharia</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/5.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Nanaji_Deshmukh" target="_blank">Nanji Deshmukh</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/6.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Pandurang_Shastri_Athavale" target="_blank">Pandunnag Shastri Athavale</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>   
    </div>
    </section>
    <section>
      <div class="container">
        <div class="section-title">
          <div class="row">
            <div class="col-md-6">
              
              
            </div>
          </div>
        </div>
     <div class="section-content">
          <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/7.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Baba_Amte" target="_blank">Baba Amte</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/8.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Usha_Mehta" target="_blank">Usha Mehta</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/9.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Kamaladevi_Chattopadhyay" target="_blank">Kamaladevi Chattopadhyay</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="award/10.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h4 class="mt-0"><a href="https://en.wikipedia.org/wiki/Mirabehn" target="_blank">Mirabehn</a></h4>
                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>   
    </div>
    </section>
    
    
  </div>
  <!-- end main-content -->
  </body>
  </html>
  
  <!-- end main-content -->
  
  <!-- Footer --><?php include('footer.php') ?>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

<!-- Mirrored from kodesolution.com/demo/wxyz/y/ngopress/v2.0/demo/page-gallery-boxed-with-caption-3col.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 03 Feb 2018 09:01:24 GMT -->
</html>