<?php
session_start();
if(!isset($_SESSION['user'])&&$_SESSION['type']=="college"){
    header('Location:nss-login.php');
}
include ('db-config.php');
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
   <!-- Header -->
   <?php 

   include('headerlogout.php');
   ?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-6" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <?php 
    include 'db-config.php';
    $user=$_SESSION['user'];
    $result=mysqli_query($con,"select * from college_details_table where college_id='$user'");
    if($row=mysqli_fetch_array($result)){
      $college_name=$row[2];
      $chairman_name=$row[12];
    $principal_name=$row[16];
    $college_po_name=$row[20];
    
    $description=$row[3];

    $chairman_image=$row[14];
    $principal_image=$row[18];
 
  $college_po_image=$row[22];
  
  $college_image=$row[10];
  $chairman_number=$row[15];
  $chairman_email=$row[13];
  $principal_number=$row[19];
  $principal_email=$row[17];
  $college_po_number=$row[23];
  $college_po_email=$row[21];
    
    }else{
      $chairman_number=null;
  $chairman_email=null;
  $principal_number=null;
  $principal_email=null;
  $college_po_number=null;
  $college_po_email=null;
      $college_name=null;
      $chairman_name=null;
    $principal_name=null;
    $college_po_name=null;
    
    $description=null;
    $chairman_image=null;
      $principal_image=null;
   
    $college_po_image=null;
    
    $college_image=null;
    
    }
    
    

    
    
?>
              <h3 class="font-28 text-white"><?php echo $college_name; ?></h2>

            </div>
          </div>
        </div>
      </div>      
    </section>
    <div class="row" style="margin-top:20px;">
      <div class="col-md-4">
  <img src="images/logo-wide.png " style="margin-left:20px;height:auto;width:165px;"/>
</div>
<div class="col-md-4">
  <h3 style=" margin-top:70px;">National Service Scheme</h3>
</div>
    <div class="col-md-4">
      <center>
  <img src="<?php if($college_image==null){echo "images/vardhaman.png";}else{echo "uploads/".$user."/images/".$college_image;} ?>" style="margin-right:20px;height:auto;width:200px;"/>
</center>
</div>
</div>
<section>
      <div class="container">
        <div class="section-content">
          <div class="heading-line-bottom">
            <h3 class="heading-title">College Details</h3>
          </div>
          <div class="row">
            <div class="col-xs-12 col-sm-4 col-md-4">
              <div class="image-box-thum">
                <img style="height:330px !important;width:420px !important;" src="<?php if($chairman_image==null){echo "https://placehold.it/360x240";}else{echo "uploads/".$user."/images/".$chairman_image;} ?>" alt="">
              </div>
              <div class="image-box-details text-center p-20 pt-30 pb-30 bg-lighter">
                <h3 class="title mt-0">Chairman</h3>
                <h3 class="title mt-0"><?php if($chairman_name==null){echo "";}else{echo $chairman_name;} ?></h3>
                <h4 class="title mt-0"><?php if($chairman_number==null){echo "";}else{echo $chairman_number;} ?></h4>
                <h4 class="title mt-0"><?php if($chairman_email==null){echo "";}else{echo $chairman_email;} ?></h4>
              </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4">
              <div class="image-box-thum">
                <img style="height:330px !important;width:420px !important;" src="<?php if($principal_image==null){echo "https://placehold.it/360x240";}else{echo "uploads/".$user."/images/".$principal_image;} ?>" alt="">
              </div>
              <div class="image-box-details text-center p-20 pt-30 pb-30 bg-lighter">
                <h3 class="title mt-0">Principal</h3>
                <h3 class="title mt-0"><?php if($principal_name==null){echo "";}else{echo $principal_name;} ?></h3>
                <h4 class="title mt-0"><?php if($principal_number==null){echo "";}else{echo $principal_number;} ?></h4>
                <h4 class="title mt-0"><?php if($principal_email==null){echo "";}else{echo $principal_email;} ?></h4>
              </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4">
              <div class="image-box-thum">
                <img style="height:330px !important;width:420px !important;" src="<?php if($college_po_image==null){echo "https://placehold.it/360x240";}else{echo "uploads/".$user."/images/".$college_po_image;} ?>" alt="">
              </div>
              <div class="image-box-details text-center p-20 pt-30 pb-30 bg-lighter">
                <h3 class="title mt-0">College PO</h3>
                <h3 class="title mt-0"><?php if($college_po_name==null){echo "";}else{echo $college_po_name;} ?></h3>
                <h4 class="title mt-0"><?php if($college_po_number==null){echo "";}else{echo $college_po_number;} ?></h4>
                <h4 class="title mt-0"><?php if($college_po_email==null){echo "";}else{echo $college_po_email;} ?></h4>
               </div>
            </div>
          </div>

          <div class="col-md-12">
          <div class="heading-line-bottom">
            <h3 class="heading-title">College Description</h3>
          </div>
          <div class="row">
            <div class="col-xs-12">
            <p style="text-align:justify;">
            <?php echo $description; ?>
            </p>
            </div>
           
          </div>

          </div>
          <div class="col-md-12">
            <hr>
            <div class="heading-line-bottom">
              <h4 class="heading-title">Link's</h4>
            </div>
            <div class="row">
              <div class="col-md-6">
                <ul class="list-group">

                  <a href="nss-college-profile.php" class="list-group-item list-group-item-info">Upload Your College Information</a>
                  <a href="nss-faculty.php" class="list-group-item list-group-item-warning">Faculty Details</a>
                  <a href="nss-display-gallery.php" class="list-group-item list-group-item-danger">Upload Gallery</a>
                  <a href="nss-change-password.php" class="list-group-item list-group-item-danger">Change Password</a>
                  <a href="nss-student-add.php" class="list-group-item list-group-item-danger">Add student</a>
                </ul>                
              </div>
              <div class="col-md-6">
                <div class="list-group">
                 
                  <a href="nss-student.php" class="list-group-item list-group-item-info">Student Details</a>
                  <a href="nss-upload.php" class="list-group-item list-group-item-warning">Upload Awards</a>
                  <a href="nss-display-award.php" class="list-group-item list-group-item-danger">Display Awards and gallery</a>
                  <a href="nss-college-notifications.php" class="list-group-item list-group-item-danger">Notifications</a>
                  <a href="nss-student-delete.php" class="list-group-item list-group-item-danger">Delete student</a>
                </div>                
              </div>
            </div>
          </div>
          </div>
          </div>
          </section>
          
          <section id="contact" data-bg-img="images/pattern/p4.png"> 
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <h2 class="text-uppercase font-28 mt-0"><span class="text-theme-colored">Contact</span> Us</h2>
            </div>
          </div>
        </div>
        <div class="section-content">          
          <div class="row">
            <div class="col-md-12">
            
              <!-- Contact Form -->
              <?php 
                    if(isset($_POST['submit']))
                    mail($_POST['form_email'],$_POST['form_subject'],$_POST['form_message'],"from : xyz@gmail.com");

                    ?>
              <form class="contact-form-transparent" id="contact_form"  name="contact-form" method="post">
                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                      <input id="form_name" name="form_name" class="form-control" type="text" placeholder="Enter Name" required="">
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="form-group">
                      <input id="form_phone" name="form_phone" class="form-control" type="text" placeholder="Enter Phone" required="">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <input id="form_email" name="form_email" class="form-control required email" type="email" placeholder="Enter Email">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <input id="form_subject" name="form_subject" class="form-control required" type="text" placeholder="Enter Subject">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <textarea id="form_message" name="form_message" class="form-control required" rows="5" placeholder="Enter Message"></textarea>
                </div>
                <div id="contact-form-result" class="alert alert-success" role="alert" style="display: none;">
                </div>
                <div class="form-group text-center mb-0">
                  <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="" />
                  <button data-loading-text="Please wait..." class="btn btn-colored btn-rounded btn-theme-colored pl-30 pr-30" name="submit" type="submit">Send your message</button>
                </div>
              </form>
              <!-- Contact Form Validation-->
              <!--script type="text/javascript">
                $("#contact_form").validate({
                  submitHandler: function(form) {
                    var form_btn = $(form).find('button[type="submit"]');
                    var form_result_div = '#form-result';
                    $(form_result_div).remove();
                    form_btn.before('<div id="form-result" class="alert alert-success" role="alert" style="display: none;"></div>');
                    var form_btn_old_msg = form_btn.html();
                    form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                    $(form).ajaxSubmit({
                      dataType:  'json',
                      success: function(data) {
                        if( data.status == 'true' ) {
                          $(form).find('.form-control').val('');
                        }
                        form_btn.prop('disabled', false).html(form_btn_old_msg);
                        $(form_result_div).html(data.message).fadeIn('slow');
                        setTimeout(function(){ $(form_result_div).fadeOut('slow') }, 6000);
                      }
                    });
                  }
                });
              </script-->

            </div>
          </div>
        </div>
      </div>
    </section>
  <!-- end main-content -->

  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>