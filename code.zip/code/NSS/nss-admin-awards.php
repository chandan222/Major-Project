<?php
session_start();
if(!isset($_SESSION['user'])&&$_SESSION['type']!="university"){
    header('Location:nss-login.php');
}
include ('db-config.php');
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
   <!-- Header -->
   <?php 

   include('headerlogout.php');
   ?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-6" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h3 class="font-28 text-white">Login/Register</h2>
              <ol class="breadcrumb text-center text-black mt-10">
                <li><a href="#">Home</a></li>
                <li><a href="#">Pages</a></li>
                <li class="active text-theme-colored">Page Title</li>
              </ol>
            </div>
          </div>
        </div>
      </div>      
    </section>

    <section>
      <div class="container">
                     
      <form method="POST"  enctype="multipart/form-data">
      <div class="form-group">
  <label for="exampleInputEmail2">District</label>
  <!--<select class="form-control"  name="district" >
  <option>Select District</option>
        <option>Rangareddy</option>
  </select>-->
  <select class ="form-control" name="district" id="district">
    <option value=''>------- Select --------</option>
    <?php
    $sql = "select distinct districtname from `district_college`";
    $res = mysqli_query($con, $sql);
    if(mysqli_num_rows($res) > 0) {
      while($row = mysqli_fetch_object($res)) {
        echo "<option value='".$row->districtname."'>".$row->districtname."</option>";
      }
    }
    ?>
  </select>
  </div>
  <div class="form-group">
  <label for="exampleInputEmail2">College</label>
  <!--<select class="form-control" name="college" >
  <option>Select College</option>
        <option>Vmeg</option>
        <option>Snist</option>
        <option>CVR</option>
  </select>-->
  <label>College :</label>
  <select class ="form-control" name="college" id="college"><option>------- Select --------</option></select>
  </div><center>
  <button type="submit" name="submit" class="btn btn-default">Submit</button></center>
  </form>    
       
    </div>

<?php

if(isset($_POST['submit'])){ 
    
    $college=$_POST['college'];
    
    $district=$_POST['district'];
    
    $result=mysqli_query($con,"select * from district_college where collegename='$college'");
    $row=mysqli_fetch_array($result);
    $college_id=$row[2];
    $user=strtolower($college_id);
    ?>
    <div class="container-flow">
    <div class="row">
      <div class="col-md-12 ">
        <ul class="nav nav-tabs">
          <li class="active"><a href="#login-tab" data-toggle="tab">Awards</a></li>
          <li><a href="#register-tab" data-toggle="tab">Gallery</a></li>
        </ul>
        <div class="tab-content">
          <div class="tab-pane fade in active p-15" id="login-tab">
            <h4 class="text-gray mt-0 pt-5"> Awards</h4>
            <hr>
            <p>Lorem ipsum dolor sit amet, consectetur elit.</p>
            <div class="row">
      <?php 
$result=mysqli_query($con,"select * from award where college_id='$college_id'");
while($row=mysqli_fetch_array($result)){
   ?>
<div class="col-xs-12 col-sm-4 col-md-4">
           <div class="item">
              <div class="causes bg-white maxwidth500 mb-sm-30">
                <div class="thumb">
                  <img src="<?php echo "uploads/".$user."/images/".$row[2]; ?>" style="width:200px !important;height:200px !important;" alt="" class="img-fullwidth">
                  
                </div>
                
                <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                  <h5 class="font-weight-600 font-16"><a href="page-single-cause.html"><?php echo $row[4] ?></a></h5>
                  <p>
<p><?php echo $row[0]; ?></p>
<p><b>Year :</b> <?php echo $row[3]; ?></p>
<p><?php echo $row[1]; ?></p>
                 
                </div>
              </div>
            </div>

</div>

   <?php
}
?>
     
            </div>
          </div>
          <div class="tab-pane fade in p-15" id="register-tab">
          <h4 class="text-gray mt-0 pt-5"> Gallery</h4>
            <hr>
            <div class="row">
            <?php 


$result=mysqli_query($con,"select * from gallery where college_id='$college_id'");
while($row=mysqli_fetch_array($result)){
   ?>
    <div class="col-xs-12 col-sm-4 col-md-4">
           <div class="item">
              <div class="causes bg-white maxwidth500 mb-sm-30">
                <div class="thumb">
                  <img src="<?php echo "uploads/".$user."/images/".$row[2]; ?>" style="width:200px !important;height:200px !important;" alt="" class="img-fullwidth">
                  
                </div>
                
                <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                  <h5 class="font-weight-600 font-16"><a href="page-single-cause.html"><?php echo $row[4] ?></a></h5>
                  <p>
<p><?php echo $row[0]; ?></p>
<p><b>Year :</b> <?php echo $row[1]; ?></p>

                 
                </div>
              </div>
            </div>
</div>

    <div class="col-xs-12 col-sm-4 col-md-4">
           <div class="item">
              <div class="causes bg-white maxwidth500 mb-sm-30">
                <div class="thumb">
                  <img src="<?php echo "uploads/".$user."/images/".$row[3]; ?>" style="width:200px !important;height:200px !important;" alt="" class="img-fullwidth">
                  
                </div>
                
                <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                  <h5 class="font-weight-600 font-16"><a href="page-single-cause.html"><?php echo $row[4] ?></a></h5>
                  <p>
<p><?php echo $row[0]; ?></p>
<p><b>Year :</b> <?php echo $row[1]; ?></p>

                 
                </div>
              </div>
            </div>
</div>


   <?php
}
?>
     
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php
}
?>

    </section>
  </div>
  <!-- end main-content -->

  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>
<script>
$(document).ready(function() {
	$("#district").change(function() {
		var districtname = $(this).val();
    //console.log(districtname);
		if(districtname != "") {
			$.ajax({
				url:"get-colleges.php",

				data:{'d_id':districtname},
				type:'POST',
				success:function(response) {
					var resp = $.trim(response);
					$("#college").html(resp);

         // console.log(response);
				}
			});
		} else {
			$("#college").html("<option value=''>------- Select --------</option>");
		}
	});
});

</script>
