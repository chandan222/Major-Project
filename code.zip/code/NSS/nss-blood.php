
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>


<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">

   <!-- Header -->
<?php
include('header.php');
?>
  <!-- ########### MENUBAR ENDS   ######## -->




  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-6" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h3 class="font-28 text-white">Blood Donation</h2>

            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">


  <div class="row">
  <form method="POST"  enctype="multipart/form-data">
  <div class="form-group">
  <label for="exampleInputEmail2">Select State</label>
  <select name="state" class="form-control">
                    <option>Andhra Pradesh</option>
                    <option>Madhya Pradesh</option>
                    <option>Telangana</option>

                  </select>
                </div>
                <div class="form-group">
  <label for="exampleInputEmail2">Select City</label>
  <select name="city" class="form-control">
                    <option>Hyderabad</option>

                  </select>
                </div>
                <div class="form-group">
  <label for="exampleInputEmail2">Select District</label>
  <select name="district" class="form-control">
                    <option>Rangareddy</option>

                  </select>
                </div>
                <div class="form-group">
  <label for="exampleInputEmail2">Select College</label>
  <select name="college" class="form-control" multiple>
                    <option>vmeg</option>

                  </select>
                </div>
  <div class="form-group">
<label for="exampleInputEmail2">Patient Name</label>
<input type="text" class="form-control" name="name" required placeholder="Patient Name">
</div>
<div class="form-group">
<label for="exampleInputEmail2">Patient Number</label>
<input type="text" class="form-control" name="number" required placeholder="Patient Number">
</div>
  <div class="form-group">
<label for="exampleInputEmail2">Patient Age</label>
<input type="text" class="form-control" name="age" required placeholder="Patient Age">
</div>
<div class="form-group">
  <label for="exampleInputEmail2">Select College</label>
  <select name="blood" class="form-control" >
  <option value="A+">A+</option>
  <option value="A-">A-</option>
  <option value="B+">B+</option>
  <option value="B-">B-</option>
  <option value="AB+">AB+</option>
  <option value="AB-">AB-</option>
  <option value="O+">O+</option>
  <option value="O-">O-</option>


                  </select>
                </div>
                <div class="form-group">
    <label for="exampleInputEmail2"> Description</label>
    <textarea class="form-control" rows="5" required name="desc"></textarea>
  </div>
                <div class="form-group">
<label for="exampleInputEmail2">Hospital Name</label>
<input type="text" class="form-control" name="hname" required placeholder="Hospital Name">
</div>

              <div class="form-group">
<label for="exampleInputEmail2">Hospital Area</label>
<input type="text" class="form-control" name="harea" required placeholder="Hospital Area">
</div>
<div class="form-group">
<label for="exampleInputEmail2">Hospital Number</label>
<input type="text" class="form-control" name="hnumber" required placeholder="Hospital Number">
</div>



 <div class="form-group">
    <label for="exampleInputFile2"></label>
    <input type="file" name="bill" required>
  </div>

  <button type="submit" name="submit" class="btn btn-default">Submit</button>

</form>
                   <?php
                   include('db-config.php');
                   if(isset($_POST['submit'])){
                        $state=$_POST['state'];
                        $city=$_POST['city'];
                        $district=$_POST['district'];
                        $college=$_POST['college'];
                        $name=$_POST['name'];
                        $age=$_POST['age'];
                        $blood=$_POST['blood'];
                        $number=$_POST['number'];
                        $desc=$_POST['desc'];
                        $hname=$_POST['hname'];
                        $harea=$_POST['harea'];
                        $hnumber=$_POST['hnumber'];
                        $bill=$_POST['bill'];
                        $folder="uploads/blood/";
                        $uploa=$_FILES["bill"]["name"];
                        move_uploaded_file($_FILES["bill"]["tmp_name"], "$folder".$_FILES["bill"]["name"]);
                        $bill=$uploa;
                        $result=mysqli_query($con,"insert into blood(state,city,district,college,p_name,p_age,p_blood,des,h_name,h_area,h_number,bill,p_number) values('$state','$city','$district','$college','$name','$age','$blood','$desc','$hname','$harea','$hnumber','$bill','$number')");
                        if($result){
                            //mail("chandankalyani.c@gmail.com","Blood","State:".$state."   city:".$city."District:".$district."College:".$college."Patient Name:".$name."Patient Age:".$age."Blood required:".$blood." ".$desc."Hospital Name: ".$hname."Hospital Area: ".$harea."Hospital Number: ".$hnumber."Patient Number".$number,"chandankalyani.c@gmail.com");
                        }
                        $body="State:".$state."city:".$city."District:".$district."College:".$city."Patient Name:".$name."Patient Age:".$age."Blood required:".$blood." ".$desc."Hospital Name: ".$hname."Hospital Area: ".$harea."Hospital Number: ".$hnumber."Patient Number".$number;
                        //$r=mail("chandankalyani.c@gmail.com","Blood","bloodreceipt","chandankalyani.c@gmail.com");
                        $r=mail("chandankalyani.c@gmail.com","Blood Group","$body","From: chandankalyani.c@gmail.com");

                    }
                   ?>
    </section>
  </div>
  <!-- end main-content -->


  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php');?>
  <!-- ########## FOOTER ENDS ########### -->



  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>
