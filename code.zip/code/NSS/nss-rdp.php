<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
   <!-- Header -->
   <?php 

   include('header.php');
   ?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
   <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="images/bg/bg66.jpg">
      <div class="container pt-100 pb-50">
        <!-- Section Content -->
        <div class="section-content pt-100">
          <div class="row"> 
            <div class="col-md-12">
              <h1 style="color:orange;">Republic<span style="color:white;">&nbsp;Day</span> <span style="color:green;">Parade</span></h1>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section>
      <div class="container pb-20">
        <div class="section-content">
		
          <div class="row">
		  <h3 class="text-theme-colored mt-0 mb-20">&nbsp; Republic Day Parade Camps have been proved a boon for the personality development of student &nbsp; &nbsp;&nbsp;youth of the country. </h3>
            <div class="col-md-5">
              <div class="owl-carousel-1col" data-nav="true">
                <div class="item">
                  <img src="images/bg/1.jpg" alt="">                </div>
                <div class="item">
                  <img src="images/bg/2.jpg" alt="">                </div>
                <div class="item">
                  <img src="images/bg/3.jpg" alt="">                </div>
              </div>
            </div>
            <div class="col-md-7">
             
              <p class="textjustify">Government of India, the then Ministry of Human Resource Development conducted the first Republic Day Camp of NSS Volunteers in 1988 at New Delhi. Now the NSS is being run by the Ministry of Youth Affairs & Sports. Right from the beginning, these Republic Day Parade Camps have been proved a boon for the personality development of student youth of the country.  The volunteers are imparted training in leadership development and parade apart from organising various socio-cultural programmes. The R.D.Camp brings a MINI INDIA to the nation’s capital from 1st-31st January every year. It provides ample opportunities to the NSS volunteers not only to interact among themselves but also to learn and know the tradition, custom, culture, language of one state to another. These volunteers, after a month long together  stay in the camp, become able to present themselves in the more better way and constitute of bond of patriotism, national integration, brotherhood, communal harmony which is the ultimate goal of the camp.     .</p>
            <p class="textjustify">The day in R.D. Camp begins in early morning from 6 AM and extends upto 10 PM. In includes Morning Assembly, Shramdan, Yoga, Physical Training, Community Singing, Parade Practice, Lectures, Discussions, Quiz, Debate and evening Cultural programmes. The camp is managed entirely by the student volunteers and contingent leaders. The participation in Republic Day Parade on 26th January is considered as a matter of great pride for the student youth.  It is also treated as a recognition of the selfless community service rendered by the NSS volunteers throughout the country.</p>
			</div>
          </div>
          <div class="row md-10">
		  <div class="col-md-12">
		  <h3 class="text-theme-colored">Opportunities to meet  Role Modals of National/International Repute</h3>
           <p class="textjustify">During the camp the NSS volunteers are provided opportunities to meet many eminent personalities of different fields. The camp organisers invite the eminent personalities to boost the morale of NSS volunteers and the volunteers interact with them. It also helps the volunteers to broaden their knowledge level. To name a few The Hon’ble President of India, Hon’ble Vice President of India, Hon’ble Prime Minister of India, Minister of Youth Affairs & Sports, Eminent Personalities in the field of Education, Health, Social Service, Science & Technology, Sports, Environment, Fine Arts, Art & Culture,</p>
		   <p class="textjustify">In order to understand the   folk art, dance, culture a cultural evening is organised every day in such a way that each and every participating volunteer gets a chance to exhibit his talent and cultural background. </p>
           </div>
	      </div>
		   <div class="row md-10">
		   <div class="col-md-12">
		  <h3 class="text-theme-colored">Exhibition</h3>
           <p class="textjustify">The volunteers coming from all states participate in the exhibition and show their traditional dresses, handicrafts, food products etc. and the excellent work in the form of photographs and various other presentations done by their NSS units. Further it provides exposure to the volunteers in various fields.</p>
		   </div>
		   </div>
		   <div class="row md-10">
		   <div class="col-md-12">
		  <h3 class="text-theme-colored">Academic Sessions</h3>
           <p class="textjustify"> Every day a two hour long academic session is organised in the R.D. Camp. This session comprises of one hour lecture by some eminent personalities of some specific field of national/international interest followed by one hour interaction with the volunteers. It provides opportunity to think globally in the national interest. Quiz, Debate, Essay Writing, Poster Inoculation, Extempore Speech on various issues of social and national interest are the integral part of the academic session.</p>
           </div>
		   </div>
		   <div class="row md-10">
		   <div class="col-md-12">
		  <h3 class="text-theme-colored">Output</h3>
           <p class="textjustify">On the one hand, it has been proved that the one month long Republic Day Parade Camp changes the overall personality of the students. Lot of exposure and experience gained during the camp and valuable guidance of many eminent personalities of different field helps  student volunteers to take a right decision for his career. By attending the R.D. Camp the volunteers become able to adopt a good life style like they learn group living, attain leadership quality, improve communication skills, come forward to undertake any responsibilities and fulfil them. They become able to set their vision and mission in their life lying ahead   and on the other hand this R.D. Camp instills a sense and spirit of patriotism, national integration, solidarity, brotherhood, communal harmony among the student volunteers which is very much required for the betterment of the nation. Therefore Republic Day Parade Camp provides the student volunteers ample opportunities for their integrated personality development.</p>
		   <p class="textjustify">The R.D. Camps have created many eminent personalities in the country in the field of education, health, art & culture, cinema, politics besides IAS, IPS, IFS. Today these personalities are role modals for the youth of the country and gained not only national recognition but at international front. That is why the Republic Day Parade Camp is considered most attraction for the youth community in the country. Personality   of a student youth who has ever attended R.D. Camp distinguishes himself from the general mass.</p>
		   <p class="textjustify">The contingent of RD Parade is selected from the Pre Republic Day Parade Camps that are organised at Zonal level.200 volunteers of each zone take part in these camps for 10 days duration. In these camps the volunteers are imparted training on parade and other youth development programmes. Then a central selection team comprising of nominated members visit the camps to select the NSS contingent out of the participating volumeters. Two categories of volunteers mainly for Parade and Cultural activities are selected to take part in the month long RD  Parade.</p>
           </div>
		   </div>
		   
		   
          <div class="row mt-30 mb-20 pt-10 pb-20 pl-10 pr-10 bg-lighter">
            <div class="col-md-12">
              <h3 class="text-theme-colored">NSS</h3>
              <ul class="list theme-colored check ml-30 pt-10">
                <li>Should be a regular student</li>
                <li>Should have attended the orientation programmes</li>
                <li>Should have participated in the Special camp</li>
                <li>Culturally Sound</li>
                <li>Capable of building team leadership</li>
                <li>Capable to cope up with the camping atmosphere</li>
              </ul>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
			<h3 class="text-theme-colored">Pre-Republic Day  Camps</h3>
              <p class="textjustify">160 best talented and outstanding NSS volunteers are selected to participate in the Republic Day Parade  Camp through five zonal level Pre-Republic Day Camps organised by Government of India, Ministry of Youth Affairs & Sports at different five zones of the country. In these Pre-R.D. Camps of 10 days duration the various selection procedures are adopted to select the best volunteers. A rigorous training of parade practice is arranged for the volunteers to show the
talents and capability for perfect marching/drilling.</p>
<p class="textjustify"> In each camp 200 volunteers participate from the states fall under the zone. The final selection is made by a National Level Selection Committee duly formulated by the Ministry.</p>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
  <!-- end main-content -->

  
   <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>