<?php
session_start();
include('db-config.php');

if(isset($_POST['form_username_email'])){
    $user=$_POST['form_username_email'];
    $pass=$_POST['form_password'];
    $result=mysqli_query($con,"select * from login where user='$user' and pass='$pass'");
    if($row=mysqli_fetch_assoc($result)){
        $_SESSION['user']=$user;
        $_SESSION['type']= $row['type'];
        if($_SESSION['type']=="college"){
        header('Location:nss-college.php');
        }
        if($_SESSION['type']=="university"){
        header('Location:nss-admin.php');
        }
    }
}