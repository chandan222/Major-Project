<?php
session_start();
include ('db-config.php');
    $user=$_SESSION['user'];
    $college_id=$_SESSION['user'];
    $college_name=$_POST['College_name'];
    $description=$_POST['college_desc'];
    $loc=$_POST['Location'];
    $state=$_POST['State'];
    $mandal=$_POST['Mandal'];
    $district=$_POST['District'];
    $pincode=$_POST['Pincode'];
    $folder="uploads/$user/images/";
            $uploa=$_FILES["college_logo"]["name"];
            move_uploaded_file($_FILES["college_logo"]["tmp_name"], "$folder".$_FILES["college_logo"]["name"]);
            $college_logo=$uploa;
    $email=$_POST['Email'];
   $Contact_number=$_POST['Contact_number'];

    $chairman_name=$_POST['chairman_name'];
    $chairman_email=$_POST['chairman_email'];
    $folder="uploads/$user/images/";
            $uploa=$_FILES["chairman_image"]["name"];
            move_uploaded_file($_FILES["chairman_image"]["tmp_name"], "$folder".$_FILES["chairman_image"]["name"]);
            $chairman_image=$uploa;
            $Chairman_no=$_POST['Chairman_no'];

    $principal_name=$_POST['Principal_name'];
    $principal_emailid=$_POST['principal_emailid'];
    $folder="uploads/$user/images/";
            $uploa=$_FILES["Principal_image"]["name"];
            move_uploaded_file($_FILES["Principal_image"]["tmp_name"], "$folder".$_FILES["Principal_image"]["name"]);
            $Principal_image=$uploa;
            $Principal_no=$_POST['Principal_no'];

    $college_po_name=$_POST['College_po_name'];
    $CollegePO_emailid=$_POST['CollegePO_emailid'];
    $folder="uploads/$user/images/";
            $uploa=$_FILES["College_po_image"]["name"];
            move_uploaded_file($_FILES["College_po_image"]["tmp_name"], "$folder".$_FILES["College_po_image"]["name"]);
            $College_po_image=$uploa;
            $CollegePO_no=$_POST['CollegePO_no'];
    
    $uni_name=$_POST['university_name'];
    
    $Autonomous=$_POST['Autonomous'];
    $NBA=$_POST['NBA'];
    $NAAC=$_POST['NAAC'];
    $est_yr=$_POST['est_yr'];
    $col_branch=$_POST['col_branch'];
    $stu_intake=$_POST['stu_intake'];

    $folder="uploads/$user/pdf/";
            $uploa=$_FILES["Student_list"]["name"];
            move_uploaded_file($_FILES["Student_list"]["tmp_name"], "$folder".$_FILES["Student_list"]["name"]);
            $Student_list=$folder.$uploa;


            $folder="uploads/$user/pdf/";
            $uploa=$_FILES["Faculty_list"]["name"];
            move_uploaded_file($_FILES["Faculty_list"]["tmp_name"], "$folder".$_FILES["Faculty_list"]["name"]);
            $Faculty_list=$folder.$uploa;
    $Others=$_POST['Others'];
    $result=mysqli_query($con,"select * from college_details_table where college_id='$college_id'");
    if($result){
        
       // $result=mysqli_query($con,"update name set chairman_name='$chairman_name', principal_name='$principal_name', college_po_name='$college_po_name', college_name='$college_name', description='$description', uni_name='$uni_name', accre='$accreditation' where user='$user'");
     
    }
    $x=0;$y=0;
    if($NAAC=='YES'){
        $x=1;
    }
    if($NBA=='YES'){
        $y=1;
    }

    $student_name = $roll_number= $branch= $dob = $number = $email= $caste= $blood_group= $college_name="";

$file=$_FILES["Student_list"]["tmp_name"];
 $handle = fopen($file, "r");
$male= $female=0;
$first_male=$first_female=0;
$second_male=$second_female=0;
$third_male=$third_female=0;
$fourth_male=$fourth_female=0;
$first=$second=$third=$fourth=0;
     while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
         {
           $student_name = $filesop[0];
 		   $roll_number= $filesop[1];
 			 $branch =$filesop[2];
 			 $dob=$filesop[3];
 			 $number=$filesop[4];
 			 $email=$filesop[5];
 			 $caste=$filesop[6];
              $blood_group=$filesop[7];
              $college_name=$filesop[8];
              $gender=$filesop[9];
              $year=$filesop[10];
              if($year==1){
                      $first=$first+1;
                      if($gender=='male'){
                              $first_male=$first_male+1;
                              $male=$male+1;
                      }
                      if($gender=='female'){
                              $first_female=$first_female+1;
                              $female=$female+1;
                      }
              }
              if($year==2){
                $second=$second+1;
                if($gender=='male'){
                        $second_male=$second_male+1;
                        $male=$male+1;
                }
                if($gender=='female'){
                        $second_female=$second_female+1;
                        $female=$female+1;
                }
        }
        if($year==3){
                $third=$third+1;
                if($gender=='male'){
                        $third_male=$third_male+1;
                        $male=$male+1;
                }
                if($gender=='female'){
                        $third_female=$third_female+1;
                        $female=$female+1;
                }
        }
        if($year==4){
                $fourth=$fourth+1;
                if($gender=='male'){
                        $fourth_male=$fourth_male+1;
                        $male=$male+1;
                }
                if($gender=='female'){
                        $fourth_female=$fourth_female+1;
                        $female=$female+1;
                }
        }
        $sql="insert into data values($male,$female,$first,$first_male,$first_female,$second,$second_male,$second_female,$third,$third_male,$third_female,$fourth,$fourth_male,$fourth_female,'$college_name')";
        mysqli_query($con,$sql);
 			 $sql="insert into student_list values('$student_name','$roll_number' ,'$branch' , '$dob' ,'$number','$email' ,'$caste','$blood_group','$college_name','$gender','$year')";
 			 if(!mysqli_query($con,$sql)){
 			 	echo "failed";
 				}
	  }




          $faculty_name = $college_id= $number= $email = $branch = $college_name="";

          $file=$_FILES["Faculty_list"]["tmp_name"];
           $handle = fopen($file, "r");
       
               while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
                   {
                     $faculty_name = $filesop[0];
                      $college_id= $filesop[1];
                        $number =$filesop[2];
                        $email=$filesop[3];
                        $branch=$filesop[4];
                        $college_name=$filesop[5];
                      
                        $sql="insert into Faculty_list values('$faculty_name','$college_id' ,'$number' , '$email' ,'$branch','$college_name')";
                        if(!mysqli_query($con,$sql)){
                            echo "failed";
                           }
                   }














    $query="INSERT INTO `college_details_table`( `college_id`, `college_name`, `college_description`, `college_place`, `college_mandal`,
     `college_dist`, `college_state`, `college_pincode`, `college_email`, `college_image_path`, `college_phno`, `college_chairman`,
      `chairman_emailid`, `chairman_image_path`, `college_chairman_phno`, `college_principal`, `principal_emailid`, `principal_image_path`, 
      `college_principal_phno`, `college_po`, `po_emailid`, `po_image_path`, `college_po_phno`, `estd_yr`, `autonomous`, `nba_accredited`, 
      `nac_accredited`, `affiliated_university`, `no_of_branches`, `student_intake`, `others`) 
      VALUES ('$college_id','$college_name','$description','$loc','$mandal','$district','$state','$pincode','$email','$college_logo',
      '$Contact_number','$chairman_name','$chairman_email','$chairman_image','$Chairman_no','$principal_name','$principal_emailid','$Principal_image',
      '$Principal_no','$college_po_name','$CollegePO_emailid','$College_po_image','$CollegePO_no','$est_yr','$Autonomous','$y','$x','$uni_name','$col_branch',
      '$stu_intake','$Others')";
        $result=mysqli_query($con,$query);
        if($result)   
        header('Location:nss-college.php');
?>