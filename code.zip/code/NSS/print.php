
<?php
include_once("db-config.php");
$college=$_GET['college'];
$sql = "SELECT * FROM student_list where college_name='$college'";
$resultset = mysqli_query($con, $sql) or die("database error:". mysqli_error($con));
require('fpdf.php');
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',10);
// while ($field_info = mysqli_fetch_field($resultset)) {
// $pdf->Cell(20,10,$field_info->name,1);
// }
while($rows = mysqli_fetch_assoc($resultset)) {
$pdf->SetFont('Arial','',10);
$pdf->Ln();
foreach($rows as $column) {
$pdf->Cell(20,10,$column,1);
}
}
$pdf->Output();
?>
