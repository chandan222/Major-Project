<?php
session_start();
if(!isset($_SESSION['user'])&&$_SESSION['type']!="college"){
    header('Location:nss-login.php');
}else{
    $user=$_SESSION['user'];
}
include ('db-config.php');
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
   <!-- Header -->
   <?php 

include('headerlogout.php');
?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-6" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h3 class="font-28 text-white"> Delete College</h2>
             
            </div>
          </div>
        </div>
      </div>      
    </section>

    <section>
      <div class="container">
      <div class="row">
      <form method="POST"  enctype="multipart/form-data">
      <div class="form-group">
    <label for="exampleInputEmail2">Student Name</label>
    <input type="text" class="form-control" name="student_name" required placeholder="Name">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Rollnumber</label>
    <input type="text" class="form-control" name="rollnumber" required placeholder="Rollnumber">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Branch</label>
    <input type="text" class="form-control" name="branch" required placeholder="Branch">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">DOB</label>
    <input type="text" class="form-control" name="dob" required placeholder="DOB">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Number</label>
    <input type="number" class="form-control" name="number" required placeholder="Number">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">email</label>
    <input type="email" class="form-control" name="email" required placeholder="Email">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Caste</label>
    <input type="text" class="form-control" name="caste" required placeholder="Caste">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Blood Group</label>
    <input type="text" class="form-control" name="blood" required placeholder="Blood Group">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Gender</label>
    <input type="text" class="form-control" name="gender" required placeholder="Gender">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Year</label>
    <input type="text" class="form-control" name="year" required placeholder="Year">
  </div>
  <button type="submit" name="submit" class="btn btn-default">Submit</button></center>
  </form>    
  
       </div>         
    <?php 
        if(isset($_POST['submit'])){
               
                $student_name=$_POST['student_name'];
                $rollnumber=$_POST['rollnumber'];
                $branch=$_POST['branch'];
                $dob=$_POST['dob'];
                $number=$_POST['number'];
                $caste=$_POST['caste'];
                $email=$_POST['email'];
                $blood=$_POST['blood'];
                $gender=$_POST['gender'];
                $year=$_POST['year'];
              
                $result=mysqli_query($con,"insert into student_list values('$student_name','$rollnumber','$branch','$dob',$number,'$email','$caste','$blood','$user','$gender','$year')");
                if($result){
                    echo "Insertion Successfully";
                }else{
                    echo "Insertion Unsuccessful";
                }
        }
    ?>
       </div>
    </section>
  </div>
  <!-- end main-content -->

  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>
<script>
$(document).ready(function() {
	$("#district").change(function() {
		var districtname = $(this).val();
    //console.log(districtname);
		if(districtname != "") {
			$.ajax({
				url:"get-colleges.php",

				data:{'d_id':districtname},
				type:'POST',
				success:function(response) {
					var resp = $.trim(response);
					$("#college").html(resp);

         // console.log(response);
				}
			});
		} else {
			$("#college").html("<option value=''>------- Select --------</option>");
		}
	});
});

</script>
