<?php
session_start();
include ('db-config.php');

    $user=$_SESSION['user'];

  
  
        //======================================================================
        $event_name=$_POST['event_name'];
        $event_year=$_POST['event_year'];

            $folder="uploads/$user/images/";
            $uploa=$_FILES["image1"]["name"];
            echo "<br>".$uploa."<br>";
            move_uploaded_file($_FILES["image1"]["tmp_name"], "$folder".$_FILES["image1"]["name"]);
            $image1=$uploa;


            $folder="uploads/$user/images/";
            $uploa=$_FILES["image2"]["name"];
            move_uploaded_file($_FILES["image2"]["tmp_name"], "$folder".$_FILES["image2"]["name"]);
            $image2=$uploa;


            


          
            $result=mysqli_query($con,"insert into gallery values('$event_name','$event_year','$image1','$image2','$user')");
          if($result)
header('Location:nss-college.php');
?>