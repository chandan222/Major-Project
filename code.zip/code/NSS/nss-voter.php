<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
   <!-- Header -->
   <?php 

   include('header.php');
   ?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
   <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax1 layer-overlay overlay-dark-5" data-bg-img="images/bg/bg44.jpg">
      <div class="container pt-90 pb-50">
        <!-- Section Content -->
        <div class="section-content pt-100">
          <div class="row"> 
            <div class="col-md-12">
              <h2><span style="color:orange;">National</span><span style="color:white;" > Youth</span><span style="color:green;"> Convention</span></h2>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
           <!-- <h4 class="title">National Youth Convention</h4>-->
            <div data-example-id="simple-table" class="bs-example">
             <h3> Apply For Voter ID Card Online</h3><br>
   
   Exercising one's franchise is every Indian citizen's right as per the Indian Constitution and to do this, one requires a voter's ID card. Every Indian citizen above the age of 18 years is permitted to apply for a voter ID/ election card. In addition to allowing an individual to take part in the democratic process, it also serves as valid identification proof for everything from applying for a loan to buying a house. Generally people put off applying for one due to the long drawn out application process.
   
   Earlier, it was possible to apply for a voter's card only prior to an election, either local or national. However, the Election Commission of India has now made it easier to apply for a voter's card from the comfort of your home through an online application process.
   
   <h3> How To Do Online Voter Registration?</h3><br>
   The online registration process of a new Voter ID is very simple. All you have to do is go to the Election Commission of India (ECI) homepage, the official website for voter registration. The website has everything you would need to know about the election process in India, from electoral rolls to the election schedules for upcoming elections across the country. It also has a list of guidelines for voters and various application forms to register oneself. There are a number of forms, based on the service you wish to avail. These range from name change, inclusion of name in electoral roll for citizens residing in India, as well as separate forms for those who live overseas and members of the armed forces, those in government service, etc. You would have to select the form for new voter registration, which is Form 6.
   
   To find the form you have to select National Voters Service Portal on the homepage of ECI website. Under the "National Services" section, click on Apply online for new registration of voter. This will take you to the online application form.
           

<h3>Steps Involved in New Voter ID Online Application:</h3><br>
In short, the steps involved in the online application process are as follows:
<br>
Step 1 - Visit the official website of the Election Commission of India.<br>
Step 2 - Click on National Voters Services Portal.<br>
Step 3 - Click on "Apply online for registration of new voter".<br>
Step 4 - Enter details and upload the required documents.<br>
Step 5 - Click on "Submit".<br>
Once you submit, you will receive an email on the email address that you have provided. This email will have a link to a personal Voter's ID page. You will be able to track your voter ID application through this page, and you should receive your Voter ID card in a month from your application.


</div>
          </div>
        </div> 
      </div>
    </section> 
  </div>
  <!-- end main-content -->

  
   <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>