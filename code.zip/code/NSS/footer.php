<footer id="footer" class="footer" data-bg-img="images/footer-bg.png" data-bg-color="#25272e">
    <div class="container pt-70 pb-40">
      <div class="row border-bottom-black">
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <img class="mt-10 mb-20" alt="" src="images/logo-wide-white-footer.png">
            <p style="color:#FFFFFF; font-weight:bold;">Jawaharlal Nehru Technological University Hyderabad
Kukatpally, Hyderabad - 500 085, Telangana, India </p>
            <ul class="list-inline mt-5">
<li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-theme-colored mr-5"></i> 
<b style="color:#FFFFFF;">vice chancellor:040-23156109</b> </li>
<li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-theme-colored mr-5"></i> 
<b style="color:#FFFFFF;">mailid:vcjntu@jntuh.ac.in</b></li>
<li class="m-0 pl-10 pr-10"> <i class="fa fa-globe text-theme-colored mr-5"></i> 
<a class="text-gray" href="http://jntuh.ac.in/" target="_blank"><span style="color:#FFFFFF;font-weight:bold;">website:http://jntuh.ac.in/</span></a> </li>
            </ul>
          </div>
        </div>
        
		
		<div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h5 class="widget-title line-bottom" style="color:#99FF33">Call Us</h5>
            <div class="latest-posts">
              <article class="post media-post clearfix pb-0 mb-10">
<a href="#" class="post-thumb"></a>
<div class="post-right">
<h5 class="post-title mt-0 mb-5" style="color:#FFFFFF; font-weight:bold;">91-11-23073324</h5>
<p class="post-date mb-0 font-12"> &nbsp; &nbsp;zzzzzzzz</p>
<p class="post-date mb-0 font-12"><b> &nbsp; &nbsp;040-23156109</b></p>
</div>
</article>
              
			  
<article class="post media-post clearfix pb-0 mb-10">
<a href="#" class="post-thumb"><img alt="" src="images/photos/vc22.jpg"></a>
<div class="post-right">
<h5 class="post-title mt-0 mb-5" style="color:#FFFFFF; font-weight:bold;">91-11-23384513</h5>
<p class="post-date mb-0 font-12">zzzzzzzzzzzzzz</p>
<p class="post-date mb-0 font-12"><b>&nbsp; &nbsp;91-40-32422256</b></p>
</div>
</article>
           </div>
          </div>
        </div>
        
		
		<div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h5 class="widget-title line-bottom" style="color:#99FF33">Useful Links</h5>
<ul class="list angle-double-right list-border">
<li><a href="http://nccindia.nic.in/en" target="_blank">National Cadet Corps (NCC)</a></li>
             
<li><a href="http://www.indianredcross.org/" target="_blank">Indian Red Cross Society </a></li>
<li><a href="http://yhaindia.org/" target="_blank">Youth Hostel Association of India</a></li>
            

<li><a href="https://yas.nic.in/" target="_blank">Ministry of Youth Affairs & Sports</a></li>
<li><a href="http://nyks.org/" target="_blank">Nehru Yuva Kendra Sangathan</a></li>
<li><a href="http://rgniyd.gov.in/" target="_blank">Rajiv Gandhi National Institute of Youth Development</a></li>				
            </ul>
          </div>
        </div>
       
	    <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h5 class="widget-title line-bottom" style="color:#99FF33">Content Disclaimer</h5>
            <div class="opening-hours">
              <ul class="list-border">
                <li class="clearfix"> <span style="color:#FFFFFF">THIS ORGANIZATION  PROVIDES THE [nss.nic.in] AS A SERVICE  TO THE PUBLIC AND ORGANIZATION OWNERS.</span>                </li>
              </ul>
			  

<!-- hitwebcounter Code START -->
<h3 style="color:white;">people visited</h3>
<a href="#" target="_blank">
<img src="http://hitwebcounter.com/counter/counter.php?page=6901298&style=0001&nbdigits=5&type=page&initCount=0" title="good hits" Alt="good hits"   border="0" ></a>                                        
<br/>
<!-- hitwebcounter.com -->
<a href="http://www.hitwebcounter.com" title="" 
target="_blank" style="font-family: ; font-size: px; color: #; text-decoration:  ;"></></a>            </div>
          </div>
        </div>
      </div>
      
	  
	  <div class="row mt-10">
        <div class="col-md-5">        </div>                         
      </div>
    </div>
    
	
	<div class="footer-bottom bg-black-333">
      <div class="container pt-15 pb-10">
        <div class="row">
          <div class="col-md-6">
            <p class="font-11 text-black-777 m-0"><b style="color:#99FF33">Copyright &copy;2018 NSS. All Rights Reserved</b></p>
          </div>
          
		  <div class="col-md-6 text-right">
            <div class="widget no-border m-0">
              <ul class="list-inline sm-text-center mt-5 font-12">
                <li >
                  <a href="#" style="color:#99FF33">Site Developed by:</a>                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>