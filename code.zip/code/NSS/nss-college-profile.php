<?php 
session_start();
if(!isset($_SESSION['user'])&&$_SESSION['type']=="college"){
    header('Location:nss-login.php');
}
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
   <!-- Header -->
   <?php 

include('headerlogout.php');
?>
  
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-6" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h3 class="font-28 text-white">Upload College Details</h3>
             
            </div>
          </div>
        </div>
      </div>      
    </section>

    <section>
      <div class="container">
                     
      <form method="POST" action="store.php" enctype="multipart/form-data">
  
      <div class="form-group">
    <label for="exampleInputEmail2">College Name</label>
    <input type="text" class="form-control" name="College_name" required placeholder="Name">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">College Description</label>
    <textarea class="form-control" rows="5" required name="college_desc"></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Location</label>
    <input type="text" class="form-control" name="Location" required placeholder="Location">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">State</label>
    <input type="text" class="form-control" name="State" required placeholder="State">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Mandal</label>
    <input type="text" class="form-control" name="Mandal" required placeholder="Mandal">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">District</label>
    <input type="text" class="form-control" name="District" required placeholder="District">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Pincode</label>
    <input type="number" class="form-control" name="Pincode" required placeholder="Pincode">
  </div>
  <div class="form-group">
    <label for="exampleInputFile2">College Logo</label>
    <input type="file" name="college_logo" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Email</label>
    <input type="email" class="form-control" name="Email" required placeholder="College Email">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Contact Number</label>
    <input type="number" class="form-control" name="Contact_number" required placeholder="Contact Number">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Chairman Name</label>
    <input type="text" class="form-control" name="chairman_name" placeholder="Name" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Chairman Email Id</label>
    <input type="text" class="form-control" name="chairman_email" placeholder="Email id" required>
  </div>
  
  <div class="form-group">
    <label for="exampleInputFile2">Chairman's Image</label>
    <input type="file" name="chairman_image" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Chairman Phone No.</label>
    <input type="number" class="form-control" name="Chairman_no" required placeholder="Phone Number">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Principal Name</label>
    <input type="text" class="form-control" name="Principal_name" required placeholder="Name">
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail2">Principal's Email</label>
    <input type="email" class="form-control" name="principal_emailid" required placeholder="Email">
  </div>
  <div class="form-group">
    <label for="exampleInputFile2">Principal's Image</label>
    <input type="file" name="Principal_image" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Principal Phone No.</label>
    <input type="number" class="form-control" name="Principal_no" required placeholder="Phone Number">
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail2">College PO Name</label>
    <input type="text" class="form-control" name="College_po_name" required placeholder="Name">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">College PO's Email</label>
    <input type="email" class="form-control" name="CollegePO_emailid" required placeholder="Email Id">
  </div>
  <div class="form-group">
    <label for="exampleInputFile2">College PO's Image</label>
    <input type="file" name="College_po_image" required>
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail2">College PO's Phone No.</label>
    <input type="number" class="form-control" name="CollegePO_no" required placeholder="Phone Number">
  </div>

  
  <div class="form-group">
  <label for="exampleInputEmail2">University</label>
  <select class="form-control" name="university_name" >
  <option>Select University</option>
  <option>JNTU</option>
                    <option>OU</option>
                    <option>DEEMED UNIVERSITY</option>
                  </select>
                </div>
				<div class="form-group">
  <label for="exampleInputEmail2">College Type</label>
  <select class="form-control" name="Autonomous" >
  <option>Select College Type</option>
  <option>Autonomous</option>
                    <option>Non-Autonomous</option>
                  </select>
                </div>
  <div class="form-group">
  <label for="exampleInputEmail2"> NBA Accreditation</label>
  <select class="form-control" name="NBA" >
  <option>Select</option>
  <option>YES</option>
                    <option>NO</option>
                  </select>
                </div>
  
  
                <div class="form-group">
  <label for="exampleInputEmail2">NAAC Accreditation</label>
  <select class="form-control" name="NAAC" >
  <option>Select</option>
  <option>YES</option>
                    <option>NO</option>
                  </select>
                </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Established Year</label>
    <input type="number" class="form-control" name="est_yr" required placeholder="Established Year">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">No. Of Branches</label>
    <input type="number" class="form-control" name="col_branch" required placeholder="No of Branches">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">No. Of Students Intake</label>
    <input type="number" class="form-control" name="stu_intake" required placeholder="No of Students Intake">
  </div>
  
  <div class="form-group">
    <label for="exampleInputFile2">Student's List</label>
    <input type="file" name="Student_list" required>
  
  </div>
  <div class="form-group">
    <label for="exampleInputFile2">Faculty List</label>
    <input type="file" name="Faculty_list" required>
  
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Others</label>
    <textarea class="form-control" rows="5" required name="Others"></textarea>
  </div>
  
  <button type="submit" class="btn btn-default">Submit</button>
</form>  
    </section>
  </div>
  <!-- end main-content -->

  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
<?php include ('footer.php'); ?>
  
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>