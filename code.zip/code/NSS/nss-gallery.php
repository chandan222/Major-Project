<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
   <!-- Header -->
   <?php 

include('header.php');
?>
  
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="images/bg/bg1.jpg">
      <div class="container pt-100 pb-50">
        <!-- Section Content -->
        <div class="section-content pt-100">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">Gallery</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <!-- Gallery Grid 3 -->
    <section>
      <div class="container pb-20">
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
            
              <!-- Portfolio Gallery Grid -->
              <div id="grid" class="gallery-isotope grid-3 gutter clearfix">
                <!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/1.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/1.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption1 </h4>
                </div>
                <!-- Portfolio Item End -->
                
				
				
<!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/2.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/2.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption2 </h4>
                </div>
                <!-- Portfolio Item End -->
                
				
							
<!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/3.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/3.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption3 </h4>
                </div>
                <!-- Portfolio Item End -->
                
				
								
<!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/4.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/4.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption4 </h4>
                </div>
                <!-- Portfolio Item End -->
                
				
				
				
				
				<!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/5.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/5.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption5 </h4>
                </div>
                <!-- Portfolio Item End -->
                
				

<!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/6.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/6.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption6 </h4>
                </div>
                <!-- Portfolio Item End -->
                
				
	
	<!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/7.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/7.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption7 </h4>
                </div>
                <!-- Portfolio Item End -->
				
				<!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/8.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/8.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption8 </h4>
                </div>
                <!-- Portfolio Item End -->											
				
				

                
                <!-- Portfolio Item Start -->
                <div class="gallery-item design">
                  <div class="thumb">
                    <div class="flexslider-wrapper">
                      <div class="flexslider">
                        <ul class="slides">
                          <li><a href="images/gallery/9.jpg" title="Portfolio Gallery - Photo 1"><img src="images/gallery/9.jpg" alt=""></a></li>
                          <li><a href="images/gallery/10.jpg" title="Portfolio Gallery - Photo 2"><img src="images/gallery/10.jpg" alt=""></a></li>
                          <li><a href="images/gallery/11.jpg" title="Portfolio Gallery - Photo 3"><img src="images/gallery/11.jpg" alt=""></a></li>
                        </ul>
                      </div>
                    </div>
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="#"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <h4 class="text-center mt-15 mb-40">Place here your original caption9 </h4>
                </div>
                <!-- Portfolio Item End -->



				<!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/10.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/10.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption10 </h4>
                </div>
                <!-- Portfolio Item End -->	



                <!-- Portfolio Item Start -->
                <div class="gallery-item design">
                  <div class="thumb">
                    <div class="flexslider-wrapper" data-direction="vertical">
                      <div class="flexslider">
                        <ul class="slides">
                          <li><a href="images/gallery/3.jpg" title="Portfolio Gallery - Photo 1"><img src="images/gallery/3.jpg" alt=""></a></li>
                          <li><a href="images/gallery/4.jpg" title="Portfolio Gallery - Photo 2"><img src="images/gallery/4.jpg" alt=""></a></li>
                          <li><a href="images/gallery/6.jpg" title="Portfolio Gallery - Photo 3"><img src="images/gallery/6.jpg" alt=""></a></li>
                        </ul>
                      </div>
                    </div>
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="#"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <h4 class="text-center mt-15 mb-40">Place here your original caption11 </h4>
                </div>
                <!-- Portfolio Item End -->
                
				
				

				<!-- Portfolio Item Start -->
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="images/gallery/12.jpg" alt="project">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
        <a data-lightbox="image" href="images/gallery/12.jpg">
		<i class="fa fa-plus"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
   <h4 class="text-center mt-15 mb-40">Place here your original caption12 </h4>
                </div>
                <!-- Portfolio Item End -->	
				

              </div>
              <!-- End Portfolio Gallery Grid -->

            </div>
          </div>
        </div>
      </div>
    </section>

  </div>
  <!-- end main-content -->
  
  <!-- Footer -->
  <?php include('footer.php') ?>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

<!-- Mirrored from kodesolution.com/demo/wxyz/y/ngopress/v2.0/demo/page-gallery-boxed-with-caption-3col.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 03 Feb 2018 09:01:24 GMT -->
</html>