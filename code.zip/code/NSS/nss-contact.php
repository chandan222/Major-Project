<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>


<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 

include('header.php');
?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
 <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="images/bg/bg1.jpg">
      <div class="container pt-100 pb-50">
        <!-- Section Content -->
        <div class="section-content pt-100">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">Contact</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
    
	
	<h4>State Liaison Officer Address:</h4>
	<!-- Divider: Contact -->
    <section class="divider">
      <div class="container pt-0">
        <div class="row mb-60 bg-deep">
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center pt-60 pb-60 border-right">
              <i class="fa fa-phone " style="font-size:48px;color:#3DB4D9"></i>
              <h3 style="color:green;">Call Us</h3>
              <h4 style="color:#3DB4D9;font-weight:bold">Phone: 040-23237343 </h4>
			  <h4 style="color:#3DB4D9;font-weight:bold">Fax: 040-23237344</h4>
            </div>
          </div>
		  
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center  pt-60 pb-60 border-right">
              <i class="fa fa-map-marker "  style="font-size:48px;color:#3DB4D9"></i>
       <h3 style="color:green;"> Sri Rathod Datta Deputy </h3>
              <h4 style="color:#3DB4D9;font-weight:bold">Deputy Commissioner (FAC), Director of Govt. Examinations</h4>
            <h3 style="color:green;">Address</h3>
              <h4 style="color:#3DB4D9;font-weight:bold">Chapel Road, Hyderabad Telangana-500001.<br>Email : dirgovexams.tg@gmail.com, info@bseap.org</h4>
			</div>
          </div>
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center  pt-60 pb-60">
              <i class="fa fa-desktop "  style="font-size:48px;color:#3DB4D9"></i>
              <h3 style="color:green;">Website</h3>
              <a href="http://bseap.org/Index.aspx" target="_blank"><h4 style="color:#3DB4D9;font-weight:bold">http://bseap.org/Index.aspx</h4></a>            
			  </div>
          </div>
        </div>
	
	
	
	
	
	
	
	
	
	
	<h4>JNTU University Address:</h4>
	
    <!-- Divider: Contact -->
    <section class="divider">
      <div class="container pt-0">
        <div class="row mb-60 bg-deep">
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center pt-60 pb-60 border-right">
              <i class="fa fa-phone " style="font-size:48px;color:#3DB4D9"></i>
              <h3 style="color:green;">Call Us</h3>
              <h4 style="color:#3DB4D9;font-weight:bold">vice chancellor:040-23156109</h4>
			  <h4 style="color:#3DB4D9;font-weight:bold">JNTU</h4>
            </div>
          </div>
		  
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center  pt-60 pb-60 border-right">
              <i class="fa fa-map-marker "  style="font-size:48px;color:#3DB4D9"></i>
              <h3 style="color:green;"> JNTU Address</h3>
              <h4 style="color:#3DB4D9;font-weight:bold">Jawaharlal Nehru Technological University Hyderabad Kukatpally, Hyderabad - 500 085, Telangana, India</h4>
            <h3 style="color:green;"> NSS Address</h3>
              <h4 style="color:#3DB4D9;font-weight:bold">National Service Scheme (NSS) 
12/11, Jamnagar House, New Delhi 
Ph. : 91-11-23073324, 23384513 </h4>
			</div>
          </div>
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center  pt-60 pb-60">
              <i class="fa fa-desktop "  style="font-size:48px;color:#3DB4D9"></i>
              <h3 style="color:green;">Website</h3>
              <a href="http://jntuh.ac.in/" target="_blank"><h4 style="color:#3DB4D9;font-weight:bold">http://jntuh.ac.in/</h4></a>            
			  </div>
          </div>
        </div>
        
		
		
		
		
		
		<div class="row pt-10">
          <h4 class="mt-0 mb-30 line-bottom">Find Our Location</h4>
          
		  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3805.271090598402!2d78.38986691487783!3d17.49456798801449!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9186c9216501%3A0x5b92f2e1fd8fc012!2sJawaharlal+Nehru+Technological+University+Hyderabad+College+of+Engineering!5e0!3m2!1sen!2sin!4v1519310265342" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
          <!-- Google Map Javascript Codes -->
          <script src="http://maps.google.com/maps/api/js?key=AIzaSyAYWE4mHmR9GyPsHSOVZrSCOOljk8DU9B4"></script>
          <script src="js/google-map-init.js"></script>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->
    </section>
  </div>
  <!-- end main-content -->

  
   <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>