<?php
session_start();
include ('db-config.php');

    $college=$_POST['college'];
    $district=$_POST['district'];
    $result=mysqli_query($con,"select * from district_college where collegename='$college'");
    $row=mysqli_fetch_array($result);
    $college_id=$row[2];
   // echo $college_id;
    $result=mysqli_query($con,"select * from college_list where college_id='$college_id'");
    $row=mysqli_fetch_array($result);
    $password=rand(1000,999999);
    $result=mysqli_query($con,"insert into login(user,pass,type) values('$college_id','$password','college')");
$body="Login ID:".$row[1]." Password: ".$password;
    $r=mail("$row[3]","Login Details","$body","From: chandankalyani.c@gmail.com");

          //mail($row[3],"NSS Password","Login ID:".$row[1]." Password: ".$password,"From : chandan");
        echo $row[3];
        if (!file_exists('path/to/directory')) {
       // mkdir('/uploads/'.$college_id.'/', 0777 );

        mkdir('uploads/'.$college_id, 0777 );
        mkdir('uploads/'.$college_id.'/images', 0777);
        mkdir('uploads/'.$college_id.'/pdf', 0777);
        }
header('Location:nss-admin.php');
?>
