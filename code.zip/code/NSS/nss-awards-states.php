<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 

include('header.php');
?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
 <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="images/bg/bg1.jpg">
      <div class="container pt-100 pb-50">
        <!-- Section Content -->
        <div class="section-content pt-100">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">NSS AWARD WINNERS</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container mt-30 mb-30 pt-30 pb-30">
        <div class="row ">
          <div class="col-md-9 pull-right flip sm-pull-none">
            <div class="blog-posts">
              <div class="col-md-12">
                <div class="row list-dashed">
                               
                
                  
                  <article class="post clearfix mb-50 pb-30 bg-lighter">
                    <div class="entry-header">
                      <div class="post-thumb">
                        <iframe width="1000" height="800" src="x.html" name="rvr" allowfullscreen>
                        </iframe>
                      </div>
                    </div>
                    
                  </article>

                </div>
              </div>
              
            </div>
          </div>
          <div class="col-md-3">
            <div class="sidebar sidebar-right mt-sm-30">
              <div class="widget">
                <h5 class="widget-title line-bottom">States In India</h5>
                <ul class="list-divider list-border list check">
                  <li><a href="ap.html" target="rvr">Andhra Pradesh</a></li>
				  <li><a href="arp.html" target="rvr">Arunachal Pradesh</a>
     <li><a href="as.html" target="rvr">Assam</a></li>
     <li><a href="bi.html" target="rvr">Bihar</a></li>
     <li><a href="cg.html" target="rvr">Chhasttisgarh</a></li>
     <li><a href="goa.html" target="rvr">Goa </a></li>
     <li><a href="gu.html" target="rvr">Gujarath </a></li>
     <li><a href="hr.html" target="rvr"> Haryana</a></li>
     <li><a href="hp.html" target="rvr">Himachal Pradesh</a></li>
     <li><a href="jk.html" target="rvr">Jammu & Kashmir</a></li>
     <li><a href="jh.html" target="rvr">Jharkhand</a></li>
     <li><a href="ka.html" target="rvr">Karnataka</a></li>
     <li><a href="ke.html" target="rvr">Kerala</a></li>
     <li><a href="mp.html" target="rvr">Madhya Pradesh</a></li>
     <li><a href="ma.html" target="rvr">Maharashtra</a></li>
	 <li><a href="mn.html" target="rvr">Manipur</a></li>
	 <li><a href="mg.html" target="rvr">Meghalaya</a></li>
	 <li><a href="mz.html" target="rvr">Mizoram</a></li>
	 <li><a href="ng.html" target="rvr">Nagaland</a></li>
	 <li><a href="od.html" target="rvr">Odisha</a></li>
	 <li><a href="pj.html" target="rvr">Punjab</a></li>
	 <li><a href="rj.html" target="rvr">Rajasthan</a></li>
	 <li><a href="sk.html" target="rvr">Sikkim</a></li>
	 <li><a href="tn.html" target="rvr">Tamil Nadu</a></li>
	 <li><a href="tg.html" target="rvr">Telangana</a></li>
	 <li><a href="tr.html" target="rvr">Tripura</a></li>
	 <li><a href="uk.html" target="rvr">Uttarakhand</a></li>
	 <li><a href="up.html" target="rvr">Uttar Pradesh</a></li>
	 <li><a href="wb.html" target="rvr">West Bengal</a></li>
	 
             </ul>
              </div>
             
             
              
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content --> 
  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>