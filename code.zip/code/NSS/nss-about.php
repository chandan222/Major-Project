<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>




<body class="boxed-layout pt-40 pb-40 pt-sm-0">
<div id="wrapper" class="clearfix">
  
  <!-- Header -->
  <?php 
  include('header.php');
  ?>
  <!-- ########### MENUBAR ENDS   ######## -->
  
  
  
  
  <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="images/bg/bg1.jpg">
      <div class="container pt-100 pb-50">
        <!-- Section Content -->
        <div class="section-content pt-100">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">About NSS</h3>
            </div>
          </div>
        </div>
      </div>
    </section>    

    <!-- Section: About Us -->
   
    <section class="divider parallax layer-overlay overlay-deep" data-bg-img="images/bg/bg2.jpg" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row text-justify">
          <div class="col-md-6">
            
			<h3 class="line-bottom" style="color:green;">History</h3>
            <p>National Service Scheme (NSS) was launched during 1969, the birth centenary year of Mahatma Gandhi, in 37 universities involving 40000 students. NSS is an extension dimension to the higher education system to orient the student youth to community service while they are studying in educational institutions. It is being implemented by the Ministry of Youth Affairs and Sports, Government of India.</p>
			<h3 class="line-bottom" style="color:green;">Motto Of NSS</h3>  
			<p>The motto or watchword of the National Service Scheme is "NOT ME BUT YOU" which reflects the essence of democratic living and upholds the need for self-less service. NSS helps the students develop appreciation to other person's point of view and also show consideration to other living beings. The philosophy of the NSS is well doctrined in this motto, which underlines/on the belief that the welfare .of an individual is ultimately dependent on the welfare of the society on the whole and therefore, the NSS volunteers shall strive for the well-being of the society.</p>
		    <h3 class="line-bottom" style="color:green;">Symbol</h3>
             <p>The symbol for the NSS has been based on the giant Rath Wheel of the world famous Konark Sun Temple (The Black Pagoda) situated in Orissa, India. The wheel portrays the cycle of creation, preservation and release and signifies the movement in life across time and space. The symbol thus stands for continuity as well as change and implies the continuous striving of NSS for social change.</p>
		     <h3 class="line-bottom" style="color:green;">Badge</h3>  
			<p>The NSS Symbol is embossed on the badge. The eight bars in the wheel represent the 24 hours of a day. The red colour indicates that the volunteer is full of young blood that is lively, active, energetic and full of high spirit. The navy blue colour indicates the cosmos of which the NSS is tiny part, ready to contribute its share for the welfare of the mankind.</p>
		     <h3 class="line-bottom" style="color:green;">NSS Day</h3>  
			<p>24<sup>th</sup> September</p>
		 </div>
          <div class="col-md-6">
            <h3 class="line-bottom" style="color:green;">NSS Song</h3>
            <p style="text-align:center">Uthen samaj ke liye uthen uthen,<br>
Jagen swarashtra ke liye jagen jagen,<br>
Sawayam sajen vasundhara sanwar den-2<br>
</p>
<p style="text-align:center">
Hum uthen uthega jag hamare sang sathiyon,<br>
Hum badhe to sab badhenge apne ap sathiyon,<br>
Jamin pe asman ko utar den-2<br>
Sawayam sajen vasundhara sanwar den-2<br>
</p>
<p style="text-align:center">
Udasiyon ko dur kar khushi ko banten chalen,<br>
Gaon aur shahar ki durion ko patate chalen,<br>
Gyan ko parchar den prasar den<br>
Vidyan ko prachar de prasar de<br>
Swayang saje vasundhara sanwar de<br>
</p>
<p style="text-align:center">
Samarth Bal Vurdh aur narian rahe sada,<br>
Hare bhare vanon ki shawl odhti rahe dhra,<br>
Tarakhiyon ki ek nayee katar den-2.<br>
Swayang saje vasundhara sanwar de<br>
</p>
<p style="text-align:center">
Ye jati dharm bollyan bane na shool rah ki,<br>
Badhayen bel prem ki akhandta ki chah ki,<br>
Bhawna se ye chaman nikhar den<br>
Sadbhawam se ye Chamau Nikhar de<br>
Swayanm saje vasundhara sanwar de<br>
</p>
<p style="text-align:center">
Uthen samaj ke liye uthen uthen,<br>
Jagen Swarashtra ke liye jagen jagen,<br>
Sawayam sajen vasundhara Sanwar den-2<br>
 </p>    
 <h3 class="line-bottom" style="color:green;">NSS Student Volunteers</h3>
  <p>Any student enrolled as a NSS volunteer, should put in at least 240 hours of useful social work in a continuous period of two years (i.e. 120 hours per year). A work diary is to be maintained by each NSS volunteer, which will help him/her in the assessment in his/her performance. Such volunteer is eligible to get NSS Service Certificate from the colleges/University.</p>           
          </div>
        </div>
      </div>
    </section>
	
    <!-- Section: volunteers -->
    <section>
      <div class="container">
        <div class="section-title">
          <div class="row">
            <div class="col-md-6">
              <h2 class="mt-0 text-uppercase font-28"><span class="text-theme-colored font-weight-400">Administration</span></h2>
              <div class="icon">
                <i class="fa fa-hospital-o"></i>
              </div>
             
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/1.jpg" alt="" class="img-fullwidth img-responsive"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Prof.A.Venugopal</h3>
                    <p>Vice-Chancellor</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/2.jpg" alt="" class="img-fullwidth img-responsive"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.A.Govardhan</h3>
                    <p>Rector</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/3.jpg" alt="" class="img-fullwidth img-responsive"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.N.Yadaiah</h3>
                    <p>Registrar</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/4.jpg" alt="" class="img-fullwidth img-responsive"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.B.N.Bhandari</h3>
                    <p>Director Of Academic and Planning</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    
    
  </div>
  <!-- end main-content -->
  
  

  
  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <?php include('footer.php') ?>
  
  <!-- ########## FOOTER ENDS ########### -->
  
  
  
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>

</html>