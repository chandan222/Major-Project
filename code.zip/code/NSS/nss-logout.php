<?php
session_start();
unset($_SESSION['user']);
unset($_SESSION['type']);

header('Location:nss-login.php');
?>