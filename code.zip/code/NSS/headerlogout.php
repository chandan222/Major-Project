<header id="header" class="header">
    <div class="header-top p-0 bg-theme-colored xs-text-center" data-bg-img="images/footer-bg.png">
      <div class="container pt-20 pb-20" style="background-color:#ff9933;">
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="widget no-border m-0">
<a class="menuzord-brand pull-left flip xs-pull-center mb-15" href="../index.html"><img src="images/logo-wide-white.png" alt=""></a>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="widget no-border clearfix m-0 mt-5">
              <ul class="list-inline pull-right flip sm-pull-none sm-text-center mt-5">
                <li>
                  <a class="text-white" href="nss-faq.php">FAQ</a>
                </li>
                <li class="text-white">|</li>
                <li>
                  <a class="text-white" href="nss-contact.php">Help Desk</a>
                </li>
                <li class="text-white">|</li>
                <li>
                  <a class="text-white" href="nss-contact.php">Support</a>
                </li>
              </ul>
            </div>
            <div class="widget no-border clearfix m-0 mt-5">
              <ul class="styled-icons icon-gray icon-theme-colored icon-circled icon-sm pull-right flip sm-pull-none sm-text-center mt-sm-15">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

<!-- ########### MENUBAR START    ######## -->


	<div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-silver-light" style="background-color:#ff9933 !important;">
        <div class="container">
          <nav id="menuzord" class="menuzord default bg-silver-light" style="background-color:#ff9933 !important;">

<ul class="menuzord-menu">
<li class="active"><a href="../index.php" style="font-size:15px">Home</a></li>

<li><a href="#" style="font-size:15px">NSS Details</a>
<ul class="dropdown">
<li><a href="nss-about.php">About NSS</a></li>
<li><a href="nss-administration.php">NSS Administration</a></li>

<li><a href="nss-directory.php">NSS Directory</a></li>
</ul>
</li>

<li><a href="#" style="font-size:15px">NSS Awards</a>
<ul class="dropdown">
<li><a href="nss-awards.php">Awards Details</a></li>
<li><a href="nss-awards-winners-all.php">Awards Winners All</a></li>
<li><a href="nss-awards-winners-statewise.php">Awards Winners-State Wise</a></li>
<li><a href="nss-padma-vibhushan-awardees.php">Padma Vibhushan Awardees-Social Work </a></li>
</ul>
</li>

<li><a href="#" style="font-size:15px">NSS Activities</a>
<ul class="dropdown">
<li><a href="nss-regular.php">Regular Activities</a></li>
<li><a href="nss-special.php">Special Camping Programme</a></li>
<li><a href="nss-blood.php">Blood Donations</a></li>
<li><a href="nss-voter.php">Voter</a></li>

</ul>
</li>

<li><a href="#" style="font-size:15px">NSS Programs</a>
<ul class="dropdown">
<li><a href="nss-nyc.php">National Youth Convention</a></li>
<li><a href="nss-rdp.php">Republic Day Parade</a></li>
<li><a href="nss-suvichar.php">Suvichar</a></li>
</ul>
</li>


<li><a href="#" style="font-size:15px">Joined Colleges</a>
<ul class="dropdown">
<li><a href="nss-colleges-statewise.php">Colleges List-State Wise</a></li>
<li><a href="nss-colleges-districtwise.php">Colleges List-District Wise</a></li>
<li><a href="nss-college-ranks.php">College's Ranks</a>
</li>
</ul>
</li>

<li><a href="nss-gallery.php" style="font-size:15px">Gallery</a></li>
<li><a href="nss-contact.php" style="font-size:15px">Contact Us</a></li>
</ul>

<ul class="list-inline pull-right flip hidden-sm hidden-xs">
<li>
<a class="btn btn-colored btn-flat btn-theme-colored mt-15 " href="nss-logout.php"style="border-color:white !important;background-color:#ff8c00 !important;" >Logout</a>
</li>
</ul>
          </nav>
        </div>
      </div>
    </div>
  </header>
