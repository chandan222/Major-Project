<?php
session_start();
include ('db-config.php');

    $user=$_SESSION['user'];

  
  
        //======================================================================
        $award_name=$_POST['award_name'];
        $award_details=$_POST['award_description'];
        $award_year=$_POST['award_date'];
        

            $folder="uploads/$user/images/";
            $uploa=$_FILES["award_image"]["name"];
           
            move_uploaded_file($_FILES["award_image"]["tmp_name"], "$folder".$_FILES["award_image"]["name"]);
            $image1=$uploa;


          
         
            $result=mysqli_query($con,"insert into award values('$award_name','$award_details','$image1','$award_year','$user')");
            if($result){

                header('Location:nss-college.php');
            }
            
         //     echo $image1." ".$image2." ".$image3." ".$image4." ".$image5;
   // echo $user." ".$chairman_image." ".$Principal_image." ".$College_po_image." ".$college_logo." ".$Student_list." ".$Faculty_list;

  
?>