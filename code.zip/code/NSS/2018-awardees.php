 <html dir="ltr" lang="en">
 <head>
 <!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>

 
 </head>
 <body class="boxed-layout pt-40 pb-40 pt-sm-0">

   <!-- Header -->
 <header id="header" class="header">
    <div class="header-top p-0 bg-theme-colored xs-text-center" data-bg-img="images/footer-bg.png">
      <div class="container pt-20 pb-20" style="background-color:#ff9933;">
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="widget no-border m-0">
  <a class="menuzord-brand pull-left flip xs-pull-center mb-15" href="index-mp-layout1.html"><img src="images/logo-wide-white.png" alt=""></a>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="widget no-border clearfix m-0 mt-5">
              <ul class="list-inline pull-right flip sm-pull-none sm-text-center mt-5">
                <li>
                  <a class="text-white" href="nss-faq.html">FAQ</a>
                </li>
                <li class="text-white">|</li>
                <li>
                  <a class="text-white" href="nss-contact.html">Help Desk</a>
                </li>
                <li class="text-white">|</li>
                <li>
                  <a class="text-white" href="nss-contact.html">Support</a>
                </li>
              </ul>
            </div>
            <div class="widget no-border clearfix m-0 mt-5">
              <ul class="styled-icons icon-gray icon-theme-colored icon-circled icon-sm pull-right flip sm-pull-none sm-text-center mt-sm-15">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    
 <!-- Section: volunteers -->
    <section>
      <div class="container">
        <div class="section-title">
          <div class="row">
            <div class="col-md-6">
              <h2 class="mt-0 text-uppercase font-28">Our <span class="text-theme-colored font-weight-400">volunteers</span></h2>
              <div class="icon">
                <i class="fa fa-hospital-o"></i>
              </div>
             
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/1.jpg" alt="" class="img-fullwidth img-responsive"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Prof.A.Venugopal</h3>
                    <p>Vice-Chancellor</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/2.jpg" alt="" class="img-fullwidth img-responsive"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.A.Govardhan</h3>
                    <p>Rector</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/3.jpg" alt="" class="img-fullwidth img-responsive"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.N.Yadaiah</h3>
                    <p>Registrar</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/4.jpg" alt="" class="img-fullwidth img-responsive"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.B.N.Bhandari</h3>
                    <p>Director Of Academic and Planning</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Section: volunteers -->
    <section>
      <div class="container">
        <div class="section-title">
          <div class="row">
            <div class="col-md-6">
              <h2 class="mt-0 text-uppercase font-28">Our <span class="text-theme-colored font-weight-400">volunteers</span></h2>
              <div class="icon">
                <i class="fa fa-hospital-o"></i>
              </div>
             
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/1.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Prof.A.Venugopal</h3>
                    <p>Vice-Chancellor</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/2.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.A.Govardhan</h3>
                    <p>Rector</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/3.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.N.Yadaiah</h3>
                    <p>Registrar</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/4.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.B.N.Bhandari</h3>
                    <p>Director Of Academic and Planning</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
   <!-- Section: volunteers -->
    <section>
      <div class="container">
        <div class="section-title">
          <div class="row">
            <div class="col-md-6">
              <h2 class="mt-0 text-uppercase font-28">Our <span class="text-theme-colored font-weight-400">volunteers</span></h2>
              <div class="icon">
                <i class="fa fa-hospital-o"></i>
              </div>
             
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/1.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:50%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Prof.A.Venugopal</h3>
                    <p>Vice-Chancellor</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/2.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:25%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.A.Govardhan</h3>
                    <p>Rector</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/3.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:25%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.N.Yadaiah</h3>
                    <p>Registrar</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 pb-sm-30">
              <div class="team-member">
                <div class="volunteer-thumb"> <img src="images/team/4.jpg" alt="" class="img-fullwidth img-responsive" style="border-radius:25%"> </div>
                <div class="bg-lighter text-center pt-20">
                  <div class="member-biography">
                    <h3 class="mt-0">Dr.B.N.Bhandari</h3>
                    <p>Director Of Academic and Planning</p>
                  </div>
                  <ul class="styled-icons icon-theme-colored icon-circled pt-5">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    
  </div>
  <!-- end main-content -->
  </body>
  </html>
  