﻿<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="NSS, National Service Scheme, Service" />
<meta name="keywords" content="NSS, National Service Scheme, Services in INDIA" />
<meta name="author" content="NSS TEAM" />

<!-- Page Title -->
<title>National Service Scheme</title>

<!-- Favicon and Touch Icons -->
<link href="NSS/images/favicon.png" rel="shortcut icon" type="image/png">
<link href="NSS/images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="NSS/images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="NSS/images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="NSS/images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="NSS/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="NSS/css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="NSS/css/animate.css" rel="stylesheet" type="text/css">
<link href="NSS/css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="NSS/css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="NSS/css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="NSS/css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="NSS/css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="NSS/css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="NSS/js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="NSS/js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="NSS/js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="NSS/css/colors/theme-skin-blue.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="NSS/js/jquery-2.2.4.min.js"></script>
<script src="NSS/js/jquery-ui.min.js"></script>
<script src="NSS/js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="NSS/js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="NSS/js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="NSS/js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>


<body class="boxed-layout pt-40 pb-40 pt-sm-0" data-bg-img="images/pattern/p5.png">
<div id="wrapper" class="clearfix">
  <!-- preloader -->
  <div id="preloader">
    <div id="spinner">
<img class="floating" style="height:150px;width:150px !important;" src="NSS/images/logo-wide.png" alt="">
      <h5 class="line-height-50 font-18 ml-15">Welcome to NSS...</h5>
    </div>
    <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
  </div>

  <!-- Header -->
  <header id="header" class="header">
    <div class="header-top p-0 bg-theme-colored xs-text-center" data-bg-img="images/footer-bg.png">
      <div class="container pt-20 pb-20" style="background-color:#ff9933;">
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="widget no-border m-0">
<a class="menuzord-brand pull-left flip xs-pull-center mb-15" href="index-mp-layout1.php"><img src="NSS/images/logo-wide-white.png" alt=""></a>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="widget no-border clearfix m-0 mt-5">
              <ul class="list-inline pull-right flip sm-pull-none sm-text-center mt-5">
                <li>
                  <a class="text-white" href="NSS/nss-faq.php">FAQ</a>
                </li>
                <li class="text-white">|</li>
                <li>
                  <a class="text-white" href="NSS/nss-contact.php">Help Desk</a>
                </li>
                <li class="text-white">|</li>
                <li>
                  <a class="text-white" href="NSS/nss-contact.php">Support</a>
                </li>
              </ul>
            </div>
            <div class="widget no-border clearfix m-0 mt-5">
              <ul class="styled-icons icon-gray icon-theme-colored icon-circled icon-sm pull-right flip sm-pull-none sm-text-center mt-sm-15">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

<!-- ########### MENUBAR START    ######## -->


	<div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-silver-light" style="background-color:#ff9933 !important;">
        <div class="container">
          <nav id="menuzord" class="menuzord default bg-silver-light" style="background-color:#ff9933 !important;">

<ul class="menuzord-menu">
<li class="active"><a href="index.php" style="font-size:15px">Home</a></li>

<li><a href="#" style="font-size:15px">NSS Details</a>
<ul class="dropdown">
<li><a href="NSS/nss-about.php">About NSS</a></li>
<li><a href="NSS/nss-administration.php">NSS Administration</a></li>

<li><a href="NSS/nss-directory.php">NSS Directory</a></li>
</ul>
</li>

<li><a href="#" style="font-size:15px">NSS Awards</a>
<ul class="dropdown">
<li><a href="NSS/nss-awards.php">Awards Details</a></li>
<li><a href="NSS/nss-awards-winners-all.php">Awards Winners All</a></li>
<li><a href="NSS/nss-awards-winners-statewise.php">Awards Winners-State Wise</a></li>
<li><a href="NSS/nss-padma-vibhushan-awardees.php">Padma Vibhushan Awardees-Social Work </a></li>
</ul>
</li>

<li><a href="#" style="font-size:15px">NSS Activities</a>
<ul class="dropdown">
<li><a href="NSS/nss-regular.php">Regular Activities</a></li>
<li><a href="NSS/nss-special.php">Special Camping Programme</a></li>
<li><a href="NSS/nss-blood.php">Blood Donations</a></li>
<li><a href="NSS/nss-voter.php">Voter</a></li>
</ul>
</li>

<li><a href="#" style="font-size:15px">NSS Programs</a>
<ul class="dropdown">
<li><a href="NSS/nss-nyc.php">National Youth Convention</a></li>
<li><a href="NSS/nss-rdp.php">Republic Day Parade</a></li>
<li><a href="NSS/nss-suvichar.php">Suvichar</a></li>
</ul>
</li>


<li><a href="#" style="font-size:15px">Joined Colleges</a>
<ul class="dropdown">
<li><a href="NSS/nss-colleges-statewise.php">Colleges List-State Wise</a></li>
<li><a href="NSS/nss-colleges-districtwise.php">Colleges List-District Wise</a></li>
<li><a href="NSS/nss-college-ranks.php">College's Ranks</a>
</li>
</ul>
</li>

<li><a href="NSS/nss-gallery.php" style="font-size:15px">Gallery</a></li>
<li><a href="NSS/nss-contact.php" style="font-size:15px">Contact Us</a></li>
</ul>

<ul class="list-inline pull-right flip hidden-sm hidden-xs">
<li>
<a class="btn btn-colored btn-flat btn-theme-colored mt-15 " href="NSS/nss-login.php"style="border-color:white !important;background-color:#ff8c00 !important;" >Login</a>
</li>
</ul>
          </nav>
        </div>
      </div>
    </div>
  </header>

  <!-- ########### MENUBAR ENDS   ######## -->




  <!-- ########## SLIDER STARTS ########## -->

  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: home -->
    <section id="home">
      <div class="container-fluid p-0">

        <!-- Slider Revolution Start -->
        <div class="rev_slider_wrapper">
          <div class="rev_slider rev_slider_default" data-version="5.0">
            <ul>

              <!-- SLIDE 1 -->
              <li data-index="rs-1" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="NSS/images/bg/bg-slider1.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide 1" data-description="">
                <!-- MAIN IMAGE -->
                <img src="NSS/images/bg/bg-slider1.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="10" data-no-retina>
                <!-- LAYERS -->

                <!-- LAYER NR. 2 -->
                <div class="tp-caption tp-resizeme text-uppercase bg-theme-colored-transparent text-white font-raleway pl-30 pr-30"
                  id="rs-1-layer-2"

                  data-x="['center']"
                  data-hoffset="['0']"
                  data-y="['middle']"
                  data-voffset="['-20']"
                  data-fontsize="['48']"
                  data-lineheight="['70']"
                  data-width="none"
                  data-height="none"
                  data-whitespace="nowrap"
                  data-transform_idle="o:1;s:500"
                  data-transform_in="y:100;scaleX:1;scaleY:1;opacity:0;"
                  data-transform_out="x:left(R);s:1000;e:Power3.easeIn;s:1000;e:Power3.easeIn;"
                  data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
                  data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"
                  data-start="1000"
                  data-splitin="none"
                  data-splitout="none"
                  data-responsive_offset="on"
                  style="z-index: 7; white-space: nowrap; font-weight:700; border-radius: 30px;">Started in Year 1969
                </div>
              </li>



		<!-- SLIDE 2 -->
              <li data-index="rs-1" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="NSS/images/bg/bg-slider2.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide 1" data-description="">
                <!-- MAIN IMAGE -->
                <img src="NSS/images/bg/bg-slider2.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="10" data-no-retina>
                <!-- LAYERS -->

                <!-- LAYER NR. 2 -->
                <div class="tp-caption tp-resizeme text-uppercase text-white font-raleway"
                  id="rs-3-layer-2"

                  data-x="['right']"
                  data-hoffset="['35']"
                  data-y="['middle']"
                  data-voffset="['-25']"
                  data-fontsize="['32']"
                  data-lineheight="['54']"
                  data-width="none"
                  data-height="none"
                  data-whitespace="nowrap"
                  data-transform_idle="o:1;s:500"
                  data-transform_in="y:100;scaleX:1;scaleY:1;opacity:0;"
                  data-transform_out="x:left(R);s:1000;e:Power3.easeIn;s:1000;e:Power3.easeIn;"
                  data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
                  data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"
                  data-start="1000"
                  data-splitin="none"
                  data-splitout="none"
                  data-responsive_offset="on"
                  style="z-index: 7; white-space: nowrap; font-weight:600;">Achieve National Indira Gandhi Award
                </div>
              </li>


						<!-- SLIDE 3 -->
              <li data-index="rs-1" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="NSS/images/bg/bg-slider3.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide 1" data-description="">
                <!-- MAIN IMAGE -->
                <img src="NSS/images/bg/bg-slider3.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="10" data-no-retina>
                <!-- LAYERS -->

                <!-- LAYER NR. 2 -->
             <div class="tp-caption tp-resizeme text-uppercase text-white font-raleway"
                  id="rs-3-layer-2"

                  data-x="['right']"
                  data-hoffset="['35']"
                  data-y="['middle']"
                  data-voffset="['-25']"
                  data-fontsize="['32']"
                  data-lineheight="['54']"
                  data-width="none"
                  data-height="none"
                  data-whitespace="nowrap"
                  data-transform_idle="o:1;s:500"
                  data-transform_in="y:100;scaleX:1;scaleY:1;opacity:0;"
                  data-transform_out="x:left(R);s:1000;e:Power3.easeIn;s:1000;e:Power3.easeIn;"
                  data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
                  data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"
                  data-start="1000"
                  data-splitin="none"
                  data-splitout="none"
                  data-responsive_offset="on"
                  style="z-index: 7; white-space: nowrap; font-weight:600;">NSS Growth-INDIA Growth
                </div>
              </li>

            </ul>
          </div>
        <!-- end .rev_slider -->
        </div>


<!-- ########## SLIDER ENDS ########## -->


	    <!--  Revolution slider scriopt -->
        <script>
          $(document).ready(function(e) {
            $(".rev_slider_default").revolution({
              sliderType:"standard",
              sliderLayout: "auto",
              dottedOverlay: "none",
              delay: 5000,
              navigation: {
                keyboardNavigation: "off",
                keyboard_direction: "horizontal",
                mouseScrollNavigation: "off",
                onHoverStop: "off",
                touch: {
                  touchenabled: "on",
                  swipe_threshold: 75,
                  swipe_min_touches: 1,
                  swipe_direction: "horizontal",
                  drag_block_vertical: false
                },
                arrows: {
                  style:"zeus",
                  enable:true,
                  hide_onmobile:true,
                  hide_under:600,
                  hide_onleave:true,
                  hide_delay:200,
                  hide_delay_mobile:1200,
                  tmp:'<div class="tp-title-wrap">    <div class="tp-arr-imgholder"></div> </div>',
                  left: {
                    h_align:"left",
                    v_align:"center",
                    h_offset:30,
                    v_offset:0
                  },
                  right: {
                    h_align:"right",
                    v_align:"center",
                    h_offset:30,
                    v_offset:0
                  }
                },
                bullets: {
                  enable:true,
                  hide_onmobile:true,
                  hide_under:600,
                  style:"metis",
                  hide_onleave:true,
                  hide_delay:200,
                  hide_delay_mobile:1200,
                  direction:"horizontal",
                  h_align:"center",
                  v_align:"bottom",
                  h_offset:0,
                  v_offset:30,
                  space:5,
                  tmp:'<span class="tp-bullet-img-wrap">  <span class="tp-bullet-image"></span></span><span class="tp-bullet-title">{{title}}</span>'
                }
              },
              responsiveLevels: [1240, 1024, 778],
              visibilityLevels: [1240, 1024, 778],
              gridwidth: [1170, 1024, 778, 480],
              gridheight: [550, 600, 700, 720],
              lazyType: "none",
              parallax: {
                origo: "slidercenter",
                speed: 1000,
                levels: [5, 10, 15, 20, 25, 30, 35, 40, 45, 46, 47, 48, 49, 50, 100, 55],
                type: "scroll"
              },
              shadow: 0,
              spinner: "off",
              stopLoop: "on",
              stopAfterLoops: 0,
              stopAtSlide: -1,
              shuffle: "off",
              autoHeight: "off",
              fullScreenAutoWidth: "off",
              fullScreenAlignForce: "off",
              fullScreenOffsetContainer: "",
              fullScreenOffset: "0",
              hideThumbsOnMobile: "off",
              hideSliderAtLimit: 0,
              hideCaptionAtLimit: 0,
              hideAllCaptionAtLilmit: 0,
              debugMode: false,
              fallbacks: {
                simplifyAll: "off",
                nextSlideOnWindowFocus: "off",
                disableFocusListener: false,
              }
            });
          });
        </script>
        <!-- Slider Revolution Ends -->
      </div>
    </section>


   <!-- ############# 4 boxes START ####### -->

   <section>
      <div class="container-fluid pt-0 pb-0">
        <div class="section-content">
          <div class="row equal-height-inner home-boxes" data-margin-top="-130px">
            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay1">
              <div class="sm-height-auto bg-theme-colored" style="background-color:green !important;">
                <div class="text-center pt-10 pb-30">
                  <i class="flaticon-charity-shaking-hands-inside-a-heart text-white font-64"></i>
                  <h4 class="text-uppercase mt-0"><a href="#" class="text-white">NSS Unity</a></h4>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay2">
              <div class="sm-height-auto bg-theme-colored-darker2" style="background-color:green !important;">
                <div class="text-center pt-10 pb-30">
                  <i class="flaticon-charity-make-an-online-donation text-white font-64"></i>
                  <h4 class="text-uppercase mt-0"><a href="#" class="text-white">Donate Service</a></h4>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay3">
              <div class="sm-height-auto bg-theme-colored-darker3" style="background-color:green !important;">
                <div class="text-center pt-10 pb-30">
                  <i class="flaticon-charity-child-hand-on-adult-hand text-white font-64"></i>
                  <h4 class="text-uppercase mt-0"><a href="#" class="text-white">Become a Volunteer</a></h4>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay4">
              <div class="sm-height-auto bg-theme-colored-darker4" style="background-color:green !important;">
                <div class="text-center pt-10 pb-30">
                  <i class="flaticon-charity-world-in-your-hands text-white font-64"></i>
                  <h4 class="text-uppercase mt-0"><a href="#" class="text-white">World in our Hands</a></h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


   <!-- ############# 4 boxes end ####### -->







   <!-- ############# ABOUT START ####### -->
    <!-- Section: About  -->
    <section>
      <div class="container pb-30">
        <div class="section-content">
          <div class="row">
            <div class="col-md-6">
              <img class="img-fullwidth" src="NSS/images/about/about2.jpg" alt="">
              <h3 class="line-bottom"; style="color:green;">Who We Are?</h3>
<p style="text-align:justify;">National Service Scheme, under the Ministry of Youth Affairs &amp; Sports
Govt. of India, popularly known as NSS was launched in Gandhiji&#39;s Birth
Centenary Year 1969, in 37 Universities involving 40,000 students with
primary focus on the development of personality of students through
community service. Today, NSS has more than 3.2 million student
volunteers on its roll spread over 298 Universities and 42 (+2) Senior
Secondary Councils and Directorate of Vocational Education all over the
country. From its inception, more than 3.75 crores students from
Universities, Colleges and Institutions of higher learning have benefited
from the NSS activities, as student volunteers.</p>
      <a class="text-theme-colored font-13" href="NSS/nss-about.html">Read More →</a>
</div>


<div class="col-md-6">
			  <h3 class="line-bottom mt-0 mt-sm-30" style="color:green;">Our Vision</h3>
			  <p class="mb-30" style="text-align:justify;">The vision is to build the youth with the mind and spirit to serve the society and work for the social uplift of the down-trodden masses of our nation as a movement.</p>

<h3 class="line-bottom mt-0 mt-sm-30" style="text-align:justify;color:green;">Our Mission</h3>
<p class="mb-30">The National Service Scheme has been functioning with the motto “NOT ME BUT YOU” in view of making the youth inspired in service of the people and hence NSS Aims Education through Community Service and Community Service through Education.It's main objectives are:
<a class="text-theme-colored font-13" href="NSS/nss-about.html">Read More →</a>
</p>



              <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6">
                  <div class="icon-box p-0 mb-30">
                    <a class="icon icon-sm pull-left sm-pull-none flip bg-theme-colored mb-sm-15 mb-0 mr-10" href="#">
                      <i class="flaticon-charity-shelter text-white font-36"></i>
                    </a>
                    <h4 class="icon-box-title m-0 mb-5">Serve in Village</h4>

                  </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6">
                  <div class="icon-box p-0 mb-30">
                    <a class="icon icon-sm pull-left sm-pull-none flip bg-theme-colored mb-sm-15 mb-0 mr-10" href="#">
                      <i class="flaticon-charity-shaking-hands-inside-a-heart text-white font-36"></i>
                    </a>
                    <h4 class="icon-box-title m-0 mb-5">Share your love</h4>

                  </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6">
                  <div class="icon-box p-0 mb-30">
                    <a class="icon icon-sm pull-left sm-pull-none flip bg-theme-colored mb-sm-15 mb-0 mr-10" href="#">
                      <i class="flaticon-charity-alms text-white font-36"></i>
                    </a>
                    <h4 class="icon-box-title m-0 mb-5">Charity for Poor</h4>

                  </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6">
                  <div class="icon-box p-0 mb-30">
                    <a class="icon icon-sm pull-left sm-pull-none flip bg-theme-colored mb-sm-15 mb-0 mr-10" href="#">
                      <i class="flaticon-charity-world-in-your-hands text-white font-36"></i>
                    </a>
                    <h4 class="icon-box-title m-0 mb-5">Save our earth</h4>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
   <!-- ############# ABOUT ENDS ####### -->


    <!-- Section: home-boxes -->
    <section>
      <div class="container pt-0">
        <div class="section-content">
          <div class="row equal-height-inner home-boxes">
            <div class="col-sm-12 col-md-4 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInUp" data-wow-duration="0.6s" data-wow-delay="0.1s">
              <div class="sm-height-auto bg-theme-colored">
                <div class="p-30 mb-sm-30">
                  <h3 class="text-uppercase text-white mt-0">Become a Volunteer</h3>
                  <p class="text-white">Join hands with US.</p>
                  <a href="page-become-a-volunteer.html" class="btn btn-border btn-circled btn-transparent btn-sm">Join us Now</a>
                </div>
                <i class="flaticon-charity-shaking-hands-inside-a-heart bg-icon"></i>
              </div>
            </div>
            <div class="col-sm-12 col-md-4 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInUp" data-wow-duration="0.6s" data-wow-delay="0.1s">
              <div class="sm-height-auto bg-theme-colored-darker2">
                <div class="p-30 mb-sm-30">
                  <h3 class="text-uppercase text-white mt-0">Adopt a School</h3>
                  <p class="text-white">Education must teach life.</p>
                  <a href="#" class="btn btn-border btn-circled btn-transparent btn-sm">Contact us</a>
                </div>
                <i class="flaticon-charity-home-insurance bg-icon"></i>
              </div>
            </div>
            <div class="col-sm-12 col-md-4 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInUp" data-wow-duration="0.6s" data-wow-delay="0.1s">
              <div class="sm-height-auto bg-theme-colored-darker3">
                <div class="p-30 mb-sm-30">
                  <h3 class="text-uppercase text-white mt-0">Promote NSS</h3>
                  <p class="text-white">Encourage NSS Activities.</p>
                  <a href="page-donate.html" class="btn btn-border btn-circled btn-transparent btn-sm">Know Us</a>
                </div>
                <i class="flaticon-charity-make-an-online-donation bg-icon"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


<!-- ############# UPCOMING EVENTS STARTS ####### -->
<?php
$con = mysqli_connect("localhost", "root", "", "nss");
$query = "SELECT * FROM notifications";
$result = mysqli_query($con, $query);
 ?>

<!-- Section: Upcoming Events -->
    <section class="bg-silver-light">
      <div class="container">
        <div class="section-content">
          <div class="row">

<div class="col-md-4">
<h3 class="text-uppercase title line-bottom mt-0 mb-30"><i class="fa fa-sun-o text-gray-darkgray mr-10"></i><span class="text-theme-colored">Past Events</span></h3>

<marquee direction="down"  behavior="scroll" scrollamount="5">
  <?php while ($row = mysqli_fetch_array($result)) {
  $path=$row['file_path'];
  echo'
<article class="post media-post clearfix pb-0 mb-10">
<a href="#" class="post-thumb mr-20"><img style="width:100px !important; height:100px !important;" alt="" src="NSS/uploads/notifications/'.$path.'"></a>
<div class="post-right">
<h4 class="mt-0 mb-5"><a href="page-single-event.html">'.$row["event_name"].'</a></h4>
<ul class="list-inline font-12 mb-5">
<li class="pr-0"><i class="fa fa-calendar mr-5"></i> '.$row["year"].' </li>
</ul>
</div>
</article>';
}
?>

</marquee>
</div>

<?php
$con = mysqli_connect("localhost", "root", "", "nss");
$query = "SELECT * FROM notifications";
$result = mysqli_query($con, $query);
 ?>


<div class="col-md-4">
<h3 class="text-uppercase title line-bottom mt-0 mb-30"><i class="fa fa-bolt text-gray-darkgray mr-10"></i> <span class="text-theme-colored">Upcoming Events</span></h3>

<marquee direction="up"  behavior="scroll" scrollamount="5">
  <?php while ($row = mysqli_fetch_array($result)) {
    $path=$row["file_path"];
  echo '
  <article class="post media-post clearfix pb-0 mb-10">
  <a href="#" class="post-thumb mr-20"><img style="width:100px !important; height:100px !important;" alt="" src="NSS/uploads/notifications/'.$path.'"></a>
  <div class="post-right">
  <h4 class="mt-0 mb-5"><a href="page-single-event.html">'.$row["event_name"].'</a></h4>
  <ul class="list-inline font-12 mb-5">
  <li class="pr-0"><i class="fa fa-calendar mr-5"></i> '.$row["year"].' </li>
  </ul>
  <p class="mb-0 font-13">Lorem ipsum dolor sit amet, consectetur adipisicing elit, Quas eveniet.</p>
  <a class="text-theme-colored font-13" href="page-single-event.html">Read More →</a>
  </div>
  </article>';

  }
  ?></marquee>
</div>


<div class="col-md-4">
<h3 class="text-uppercase title line-bottom mt-0 mb-30"><i class="fa fa-calendar text-gray-darkgray mr-10"></i><span class="text-theme-colored">Calendar</span></h3>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">National Youth Day </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>12th January</h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">Event Title </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i> February </h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">International Womens Day </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>8th March</h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">World Health Day </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>7th April </h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">Anti-terrorism Day </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>21st May</h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">World Environment Day </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>5th June </h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">World Population Day </a>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>11th July </h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">Independence Day </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<i class="fa fa-calendar mr-5"></i>15th August </h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">NSS Day </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>24th September </h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">National Blood Donation Day</a>&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>1st October </h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">National Integration Day </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>19th November </h5>
</div>
</article>

<article class="post media-post clearfix pb-0 mb-10">
<div class="post-right">
<h5 class="mt-0 mb-5" ><a href="page-single-event.html">World Human Rights Day </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calendar mr-5"></i>10th December </h5>
</div>
</article>


            </div>
          </div>
        </div>
      </div>
    </section>
	<section>



<!-- ############# UPCOMING EVENTS ENDS ####### -->





<!-- ########### COLLEGE RANKS START ############ -->
<?php
$con = mysqli_connect("localhost", "root", "", "nss");
$query = "SELECT * FROM ranking order by total ASC LIMIT 3;";
$result = mysqli_query($con, $query);
?>

<section>
<br>
<?php
 while ($row = mysqli_fetch_array($result)) {
   echo'
	            <div class="col-md-12">
              <h3 class="text-uppercase title line-bottom mt-0 mb-30 mt-sm-40"><i class="fa fa-diamond"></i>&nbsp;College <span class="text-theme-colored">Ranks</span></h3>
              <div class="owl-carousel-3col">
                <div class="item">
                  <div class="causes bg-white maxwidth500 mb-sm-30">
                    <div class="thumb">
                      <img src="NSS/uploads/ranking/'.$row["college_id"].'.jpg" alt="" class="img-fullwidth">
                      <div class="overlay-donate-now">
                        <a href="page-donate.html" class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10">Rank 1</a>
                      </div>
                    </div>

                    <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                      <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">'.$row["college_id"].'</a></h5>
                      <p>
College Address</p>
                      <ul class="list-inline font-weight-600 border-top clearfix mt-20 pt-10">

                        <li class=" pull-left pr-0">RANK 1</li>
                      </ul>
                    </div>
                  </div>
                </div>';?>
                <?php
                if($row = mysqli_fetch_array($result))
                echo'<div class="item">
                  <div class="causes bg-white maxwidth500 mb-sm-30">
                    <div class="thumb">
                      <img src="NSS/uploads/ranking/'.$row["college_id"].'.jpg" alt="" class="img-fullwidth">
                      <div class="overlay-donate-now">
                        <a href="page-donate.html" class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10">Rank 2</a>
                      </div>
                    </div>

                    <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                      <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">'.$row["college_id"].'</a></h5>
                      <p>
College Address</p>
                      <ul class="list-inline font-weight-600 border-top clearfix mt-20 pt-10">

                        <li class=" pull-left pr-0">RANK 2</li>
                      </ul>
                    </div>
                  </div>
                </div>';?>
                <?php
                if($row = mysqli_fetch_array($result))
                echo'<div class="item">
                  <div class="causes bg-white maxwidth500 mb-sm-30">
                    <div class="thumb">
                      <img src="NSS/uploads/ranking/'.$row["college_id"].'.jpg" alt="" class="img-fullwidth">
                      <div class="overlay-donate-now">
                        <a href="page-donate.html" class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10">Rank 3</a>
                      </div>
                    </div>

                    <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                      <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">'.$row["college_id"].'</a></h5>
                      <p>
College Address</p>
                      <ul class="list-inline font-weight-600 border-top clearfix mt-20 pt-10">

                        <li class=" pull-left pr-0">RANK 3</li>
                      </ul>
                    </div>
                  </div>
                </div>';}?>

              </div>
            </div>
	</section>

<!-- ########### COLLEGE RANKS ENDS ############ -->









    <!-- Divider: Become a Volunteer -->
    <section class="divider parallax layer-overlay overlay-dark-4" data-bg-img="NSS/images/bg/bg13.jpg" data-parallax-ratio="0.7">
      <div class="container pt-110 pb-110">
        <div class="row">
          <div class="col-md-8">

            <h2 class="text-white font-36 text-uppercase font-weight-600 mt-0"> <span class="text-theme-colored"> Become a Proud Volunteer</span></h2>
            <p class="text-white font-28 text-uppercase font-weight-600 mt-0">Only a life lived for others is worth living.</p>
<p class="text-white font-20 text-uppercase font-weight-600 mt-0" align="right">-Albert Einstein</p>

          </div>
        </div>
      </div>
    </section>

    <!-- Section: Causes -->
    <section class="bg-silver-light">
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <h2 class="text-uppercase line-bottom-center mt-0" style="color:green;">Let Us Do</h2>

            </div>
          </div>
        </div>
        <div class="row multi-row-clearfix">
          <div class="col-sm-6 col-md-3 col-lg-3">
            <div class="causes bg-white maxwidth500 mb-30">
              <div class="thumb">
                <img src="NSS/images/letusdo/1.jpg" alt="" class="img-fullwidth">
                <div class="overlay-donate-now">

                </div>
              </div>

              <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                <h5 class="font-weight-600 font-16"><a href="page-single-cause.html"> RISE by LIFTING OTHERS</a></h5>


              </div>
            </div>
          </div>
         <div class="col-sm-6 col-md-3 col-lg-3">
            <div class="causes bg-white maxwidth500 mb-30">
              <div class="thumb">
                <img src="NSS/images/letusdo/2.jpg" alt="" class="img-fullwidth">
                <div class="overlay-donate-now">

                </div>
              </div>

              <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">WORK together as UNITY</a></h5>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
            <div class="causes bg-white maxwidth500 mb-30">
              <div class="thumb">
                <img src="NSS/images/letusdo/3.jpg" alt="" class="img-fullwidth">
                <div class="overlay-donate-now">

                </div>
              </div>

              <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">Promote SWACHH BHARAT</a></h5>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
            <div class="causes bg-white maxwidth500 mb-30">
              <div class="thumb">
                <img src="NSS/images/letusdo/4.jpg" alt="" class="img-fullwidth">
                <div class="overlay-donate-now">

                </div>
              </div>

              <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">SAVE Life</a></h5>


              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
            <div class="causes bg-white maxwidth500 mb-30">
              <div class="thumb">
                <img src="NSS/images/letusdo/5.jpg" alt="" class="img-fullwidth">
                <div class="overlay-donate-now">

                </div>
              </div>

              <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">PLANT a TREE</a></h5>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
            <div class="causes bg-white maxwidth500 mb-30">
              <div class="thumb">
                <img src="NSS/images/letusdo/6.jpg" alt="" class="img-fullwidth">
                <div class="overlay-donate-now">

                </div>
              </div>

              <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">EDUCATION is Life</a></h5>


              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
            <div class="causes bg-white maxwidth500 mb-30">
              <div class="thumb">
                <img src="NSS/images/letusdo/7.jpg" alt="" class="img-fullwidth">
                <div class="overlay-donate-now">

                </div>
              </div>

              <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">CARE People Health</a></h5>


              </div>
            </div>
          </div>
         <div class="col-sm-6 col-md-3 col-lg-3">
            <div class="causes bg-white maxwidth500 mb-30">
              <div class="thumb">
                <img src="NSS/images/letusdo/8.jpg" alt="" class="img-fullwidth">
                <div class="overlay-donate-now">

                </div>
              </div>

              <div class="causes-details clearfix border-bottom p-15 pt-10 pb-10">
                <h5 class="font-weight-600 font-16"><a href="page-single-cause.html">INDIA is in your Hands</a></h5>


              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Divider: Funfact -->
    <section class="divider parallax layer-overlay overlay-theme-colored-9" data-bg-img="NSS/images/bg/bg14.jpg" data-parallax-ratio="0.7">
      <div class="container pt-90 pb-90">
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="pe-7s-smile mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="754" class="animate-number text-white font-42 font-weight-500 mt-0 mb-0">0</h2>
              <h5 class="text-white text-uppercase font-weight-600">Happy Blood Donors</h5>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="pe-7s-rocket mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="675" class="animate-number text-white font-42 font-weight-500 mt-0 mb-0">0</h2>
              <h5 class="text-white text-uppercase font-weight-600">Success Campaigns</h5>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="pe-7s-add-user mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="3.2Million" class="animate-number text-white font-42 font-weight-500 mt-0 mb-0">0</h2>
              <h5 class="text-white text-uppercase font-weight-600">Student Volunteers </h5>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="pe-7s-global mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="298" class="animate-number text-white font-42 font-weight-500 mt-0 mb-0">0</h2>
              <h5 class="text-white text-uppercase font-weight-600">Patner Universities</h5>
            </div>
          </div>
        </div>
      </div>
    </section>















    <!-- Section: Gallery -->
    <section id="gallery">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-md-7 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
              <h3 class="text-uppercase title line-bottom mt-0 mb-30"><i class="fa fa-camera-retro text-gray-darkgray mr-10"></i>Photo <span class="text-theme-colored">Gallery</span></h3>
              <!-- Portfolio Gallery Grid -->

              <div class="gallery-isotope grid-4 gutter-small clearfix" data-lightbox="gallery">
                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm1.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg1.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm2.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg2.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm3.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg3.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm4.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg4.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm5.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg5.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm6.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg6.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm7.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg7.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm8.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg8.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm9.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg9.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm10.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg10.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm11.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg11.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->

                <!-- Portfolio Item Start -->
                <div class="gallery-item">
                  <div class="thumb">
                    <img alt="project" src="NSS/images/gallery/gallery-sm12.jpg" class="img-fullwidth">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a href="NSS/images/gallery/gallery-lg12.jpg"  data-lightbox-gallery="gallery"><i class="fa fa-picture-o"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Portfolio Item End -->
              </div>
              <!-- End Portfolio Gallery Grid -->
            </div>


			<div class="col-md-5 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
              <h3 class="text-uppercase title line-bottom mt-0 mb-30 mt-sm-40"><i class="fa fa-envelope text-gray-darkgray mr-10"></i><span class="text-theme-colored">MESSAGE</span></h3>

              <div class="bxslider bx-nav-top">
                <div class="testimonial media sm-maxwidth400 p-15 mt-0 mb-15">
                  <div class="pt-10">
                    <div class="thumb pull-left mb-0 mr-0 pr-20">
                      <img width="75" class="img-circle" alt="" src="NSS/images/testimonials/1.jpg">
                    </div>
                    <div class="ml-100 ">
                      <p>VC Message.</p>
                      <p class="author mt-10">- <span class="text-theme-colored">Univerisity VC,</span> <small><em>JNTUH</em></small></p>
                    </div>
                  </div>
                </div>
                <div class="testimonial media sm-maxwidth400 p-15 mt-0 mb-15">
                  <div class="pt-10">
                    <div class="thumb pull-left mb-0 mr-0 pr-20">
                      <img width="75" class="img-circle" alt="" src="NSS/images/testimonials/1.jpg">
                    </div>
                    <div class="ml-100 ">
                      <p>Univerisity co-ordinator message.</p>
                      <p class="author mt-10">- <span class="text-theme-colored">Univerisity co-ordinator,</span> <small><em>JNTUH</em></small></p>
                    </div>
                  </div>
                </div>
                <div class="testimonial media sm-maxwidth400 p-15 mt-0 mb-15">
                  <div class="pt-10">
                    <div class="thumb pull-left mb-0 mr-0 pr-20">
                      <img width="75" class="img-circle" alt="" src="NSS/images/testimonials/1.jpg">
                    </div>
                    <div class="ml-100 ">
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas vel sint, ut. Quisquam doloremque minus possimus.</p>
                      <p class="author mt-10">- <span class="text-theme-colored">Catherine Grace,</span> <small><em>CEO apple.inc</em></small></p>
                    </div>
                  </div>
                </div>
                <div class="testimonial media sm-maxwidth400 p-15 mt-0 mb-15">
                  <div class="pt-10">
                    <div class="thumb pull-left mb-0 mr-0 pr-20">
                      <img width="75" class="img-circle" alt="" src="NSS/images/testimonials/1.jpg">
                    </div>
                    <div class="ml-100 ">
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas vel sint, ut. Quisquam doloremque minus possimus.</p>
                      <p class="author mt-10">- <span class="text-theme-colored">Catherine Grace,</span> <small><em>CEO apple.inc</em></small></p>
                    </div>
                  </div>
                </div>
                <div class="testimonial media sm-maxwidth400 p-15 mt-0 mb-15">
                  <div class="pt-10">
                    <div class="thumb pull-left mb-0 mr-0 pr-20">
                      <img width="75" class="img-circle" alt="" src="NSS/images/testimonials/1.jpg">
                    </div>
                    <div class="ml-100 ">
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas vel sint, ut. Quisquam doloremque minus possimus.</p>
                      <p class="author mt-10">- <span class="text-theme-colored">Catherine Grace,</span> <small><em>CEO apple.inc</em></small></p>
                    </div>
                  </div>
                </div>
                <div class="testimonial media sm-maxwidth400 p-15 mt-0 mb-15">
                  <div class="pt-10">
                    <div class="thumb pull-left mb-0 mr-0 pr-20">
                      <img width="75" class="img-circle" alt="" src="NSS/images/testimonials/1.jpg">
                    </div>
                    <div class="ml-100 ">
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas vel sint, ut. Quisquam doloremque minus possimus.</p>
                      <p class="author mt-10">- <span class="text-theme-colored">Catherine Grace,</span> <small><em>CEO apple.inc</em></small></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!-- Divider: Clients -->
    <section class="clients bg-theme-colored">
      <div class="container pt-0 pb-0">
        <div class="row">
          <div class="col-md-12">
            <!-- Section: Clients -->
            <div class="owl-carousel-6col clients-logo transparent text-center">
              <div class="item"> <a href="#"><img src="NSS/images/clients/w1.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="NSS/images/clients/w2.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="NSS/images/clients/w3.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="NSS/images/clients/w4.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="NSS/images/clients/w5.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="NSS/images/clients/w6.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="NSS/images/clients/w3.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="NSS/images/clients/w4.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="NSS/images/clients/w5.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="NSS/images/clients/w6.png" alt=""></a></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->




  <!-- ########## FOOTER START ########### -->
  <!-- Footer -->
  <footer id="footer" class="footer" data-bg-img="NSS/images/footer-bg.png" data-bg-color="#25272e">
    <div class="container pt-70 pb-40">
      <div class="row border-bottom-black">
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <img class="mt-10 mb-20" alt="" src="NSS/images/logo-wide-white-footer.png">
            <p style="color:#FFFFFF; font-weight:bold;">Jawaharlal Nehru Technological University Hyderabad
Kukatpally, Hyderabad - 500 085, Telangana, India </p>
            <ul class="list-inline mt-5">
<li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-theme-colored mr-5"></i>
<b style="color:#FFFFFF;">vice chancellor:040-23156109</b> </li>
<li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-theme-colored mr-5"></i>
<b style="color:#FFFFFF;">mailid:vcjntu@jntuh.ac.in</b></li>
<li class="m-0 pl-10 pr-10"> <i class="fa fa-globe text-theme-colored mr-5"></i>
<a class="text-gray" href="http://jntuh.ac.in/" target="_blank"><span style="color:#FFFFFF;font-weight:bold;">website:http://jntuh.ac.in/</span></a> </li>
            </ul>
          </div>
        </div>


		<div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h5 class="widget-title line-bottom" style="color:#99FF33">Call Us</h5>
            <div class="latest-posts">
              <article class="post media-post clearfix pb-0 mb-10">
<a href="#" class="post-thumb"></a>
<div class="post-right">
<h5 class="post-title mt-0 mb-5" style="color:#FFFFFF; font-weight:bold;">91-11-23073324</h5>
<p class="post-date mb-0 font-12"> &nbsp; &nbsp;zzzzzzzz</p>
<p class="post-date mb-0 font-12"><b> &nbsp; &nbsp;040-23156109</b></p>
</div>
</article>


<article class="post media-post clearfix pb-0 mb-10">
<a href="#" class="post-thumb"><img alt="" src="NSS/images/photos/vc22.jpg"></a>
<div class="post-right">
<h5 class="post-title mt-0 mb-5" style="color:#FFFFFF; font-weight:bold;">91-11-23384513</h5>
<p class="post-date mb-0 font-12">zzzzzzzzzzzzzz</p>
<p class="post-date mb-0 font-12"><b>&nbsp; &nbsp;91-40-32422256</b></p>
</div>
</article>

           </div>
          </div>
        </div>


		<div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h5 class="widget-title line-bottom" style="color:#99FF33">Useful Links</h5>
<ul class="list angle-double-right list-border">
<li><a href="http://nccindia.nic.in/en" target="_blank">National Cadet Corps (NCC)</a></li>

<li><a href="http://www.indianredcross.org/" target="_blank">Indian Red Cross Society </a></li>
<li><a href="http://yhaindia.org/" target="_blank">Youth Hostel Association of India</a></li>


<li><a href="https://yas.nic.in/" target="_blank">Ministry of Youth Affairs & Sports</a></li>
<li><a href="http://nyks.org/" target="_blank">Nehru Yuva Kendra Sangathan</a></li>
<li><a href="http://rgniyd.gov.in/" target="_blank">Rajiv Gandhi National Institute of Youth Development</a></li>
            </ul>
          </div>
        </div>

	    <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h5 class="widget-title line-bottom" style="color:#99FF33">Content Disclaimer</h5>
            <div class="opening-hours">
              <ul class="list-border">
                <li class="clearfix"> <span style="color:#FFFFFF">THIS ORGANIZATION  PROVIDES THE [nss.nic.in] AS A SERVICE  TO THE PUBLIC AND ORGANIZATION OWNERS.</span>
                </li>
                </ul>


<!-- hitwebcounter Code START -->
<h3 style="color:white;">people visited</h3>
<a href="#" target="_blank">
<img src="http://hitwebcounter.com/counter/counter.php?page=6901298&style=0001&nbdigits=5&type=page&initCount=0" title="good hits" Alt="good hits"   border="0" >
</a>
<br/>
<!-- hitwebcounter.com -->
<a href="http://www.hitwebcounter.com" title=""
target="_blank" style="font-family: ; font-size: px; color: #; text-decoration:  ;"></>
</a>
            </div>
          </div>
        </div>
      </div>


	  <div class="row mt-10">
        <div class="col-md-5">
        </div>
      </div>
    </div>


	<div class="footer-bottom bg-black-333">
      <div class="container pt-15 pb-10">
        <div class="row">
          <div class="col-md-6">
            <p class="font-11 text-black-777 m-0"><b style="color:#99FF33">Copyright &copy;2018 NSS. All Rights Reserved</b></p>
          </div>

		  <div class="col-md-6 text-right">
            <div class="widget no-border m-0">
              <ul class="list-inline sm-text-center mt-5 font-12">
                <li >
                  <a href="#" style="color:#99FF33">Site Developed by:</a>
                </li>

              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <!-- ########## FOOTER ENDS ########### -->

  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="NSS/js/custom.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS
      (Load Extensions only on Local File Systems !
       The following part can be removed on Server for On Demand Loading) -->
<script type="text/javascript" src="NSS/js/revolution-slider/js/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="NSS/js/revolution-slider/js/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="NSS/js/revolution-slider/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="NSS/js/revolution-slider/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="NSS/js/revolution-slider/js/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="NSS/js/revolution-slider/js/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="NSS/js/revolution-slider/js/extensions/revolution.extension.parallax.min.js"></script>
<script type="text/javascript" src="NSS/js/revolution-slider/js/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="NSS/js/revolution-slider/js/extensions/revolution.extension.video.min.js"></script>

</body>
</html>
