-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2018 at 03:07 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nss`
--

-- --------------------------------------------------------

--
-- Table structure for table `award`
--

CREATE TABLE `award` (
  `award_name` varchar(255) NOT NULL,
  `award_description` text NOT NULL,
  `award_path` varchar(255) NOT NULL,
  `year` varchar(5) NOT NULL,
  `college_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `award`
--

INSERT INTO `award` (`award_name`, `award_description`, `award_path`, `year`, `college_id`) VALUES
('Name 2', 'The most prestigious award.', 'gallery-lg4.jpg', '2018', 'vmeg');

-- --------------------------------------------------------

--
-- Table structure for table `blood`
--

CREATE TABLE `blood` (
  `state` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `college` varchar(255) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_age` varchar(255) NOT NULL,
  `p_blood` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL,
  `h_name` varchar(255) NOT NULL,
  `h_area` varchar(255) NOT NULL,
  `h_number` varchar(255) NOT NULL,
  `bill` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `s.no` int(11) NOT NULL,
  `p_number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood`
--

INSERT INTO `blood` (`state`, `district`, `college`, `p_name`, `p_age`, `p_blood`, `des`, `h_name`, `h_area`, `h_number`, `bill`, `city`, `s.no`, `p_number`) VALUES
('Telangana', 'Rangareddy', 'vmeg', 'chandan', 'chcand', 'volvo', 'kn kn ', 'kj kj', 'kjn', 'kjn', '', 'Hyderabad', 1, 'chandan'),
('Andhra Pradesh', 'Rangareddy', '', 'natasha', '25', 'audi', 'Need blood.. Urgent', 'Care', 'Nampally', 'Care#14Nam', '6.jpg', 'Hyderabad', 2, '900411255'),
('Andhra Pradesh', 'Rangareddy', '', 'natasha', '25', 'audi', 'Need blood.. Urgent', 'Care', 'Nampally', 'Care#14Nam', '6.jpg', 'Hyderabad', 3, '900411255'),
('Andhra Pradesh', 'Rangareddy', '', 'Natasha', '25', 'volvo', 'Need Blood', 'Care', 'Nampally', 'Care#Nam1', '6.jpg', 'Hyderabad', 4, '955784125'),
('Andhra Pradesh', 'Rangareddy', '', 'Natasha', '25', 'volvo', 'Blood Needed!!', 'Care', 'Nampally', 'Care#NAM10', '7.jpg', 'Hyderabad', 5, '984712544'),
('Andhra Pradesh', 'Rangareddy', '', 'natahs', 'df', 'volvo', 'sdv', 'sdg', 'sdg', 'sdgf', '6.jpg', 'Hyderabad', 6, 'asf'),
('Andhra Pradesh', 'Rangareddy', '', 'natahs', 'df', 'volvo', 'sdv', 'sdg', 'sdg', 'sdgf', '6.jpg', 'Hyderabad', 7, 'asf'),
('Andhra Pradesh', 'Rangareddy', '', 'hjnhj', '332', 'volvo', 'dsfdsf', 'sdf', 'hjnhj', '234', '10.jpg', 'Hyderabad', 8, '324'),
('Andhra Pradesh', 'Rangareddy', '', 'Natash', '26', 'volvo', 'Need Blood', 'Care', 'Nampally', '9854712455', '6.jpg', 'Hyderabad', 9, '974581245'),
('Andhra Pradesh', 'Rangareddy', '', 'Ranvir', '27', 'audi', 'Blood Needed 2 units!', 'APOLLO', 'Banjara Hills', '954784756', '6.jpg', 'Hyderabad', 10, '965478124');

-- --------------------------------------------------------

--
-- Table structure for table `college_details_table`
--

CREATE TABLE `college_details_table` (
  `sno` int(11) NOT NULL,
  `college_id` varchar(20) NOT NULL,
  `college_name` varchar(255) NOT NULL,
  `college_description` varchar(255) NOT NULL,
  `college_place` varchar(50) NOT NULL,
  `college_mandal` varchar(50) NOT NULL,
  `college_dist` varchar(50) NOT NULL,
  `college_state` varchar(50) NOT NULL,
  `college_pincode` int(11) NOT NULL,
  `college_email` varchar(100) NOT NULL,
  `college_image_path` varchar(255) NOT NULL,
  `college_phno` int(12) NOT NULL,
  `college_chairman` varchar(100) NOT NULL,
  `chairman_emailid` varchar(100) NOT NULL,
  `chairman_image_path` varchar(255) NOT NULL,
  `college_chairman_phno` int(12) NOT NULL,
  `college_principal` varchar(100) NOT NULL,
  `principal_emailid` varchar(100) NOT NULL,
  `principal_image_path` varchar(255) NOT NULL,
  `college_principal_phno` int(12) NOT NULL,
  `college_po` varchar(100) NOT NULL,
  `po_emailid` varchar(100) NOT NULL,
  `po_image_path` varchar(100) NOT NULL,
  `college_po_phno` int(12) NOT NULL,
  `estd_yr` int(10) NOT NULL,
  `autonomous` tinyint(1) NOT NULL,
  `nba_accredited` tinyint(1) NOT NULL,
  `nac_accredited` tinyint(1) NOT NULL,
  `affiliated_university` varchar(30) NOT NULL,
  `no_of_branches` int(6) NOT NULL,
  `student_intake` int(15) NOT NULL,
  `others` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college_details_table`
--

INSERT INTO `college_details_table` (`sno`, `college_id`, `college_name`, `college_description`, `college_place`, `college_mandal`, `college_dist`, `college_state`, `college_pincode`, `college_email`, `college_image_path`, `college_phno`, `college_chairman`, `chairman_emailid`, `chairman_image_path`, `college_chairman_phno`, `college_principal`, `principal_emailid`, `principal_image_path`, `college_principal_phno`, `college_po`, `po_emailid`, `po_image_path`, `college_po_phno`, `estd_yr`, `autonomous`, `nba_accredited`, `nac_accredited`, `affiliated_university`, `no_of_branches`, `student_intake`, `others`) VALUES
(2, 'vmeg', 'Vardhaman College of Engineering', 'Mission\r\nTo adopt innovative student centric learning methods.To enhance professional and entrepreneurial skills through industry institute interaction.To train the students to meet dynamic needs of the society.To promote research and continuing education', 'Shamshabaad', 'xyz', 'Rangareddy', 'Telangana', 500031, '', 'Vardhaman.jpg', 81818181, 'Dr T Vijender Reddy', 'Vijender @vardhaman.org', 'vijender reddy.jpg', 818185865, 'Dr. S.Sai Satyanarayana ', 'Satyanarayana@vardhaman.org', 'satyanarayana.JPG', 2147483647, 'N Srinivas reddy', 'Srinivas@vardhaman.org', 'srinivas.jpg', 2147483647, 2010, 0, 1, 1, 'DEEMED UNIVERSITY', 5, 500, 'thank you');

-- --------------------------------------------------------

--
-- Table structure for table `college_list`
--

CREATE TABLE `college_list` (
  `s.no` int(1) NOT NULL,
  `college_id` varchar(20) NOT NULL,
  `college_name` varchar(255) NOT NULL,
  `college_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college_list`
--

INSERT INTO `college_list` (`s.no`, `college_id`, `college_name`, `college_email`) VALUES
(1, 'vmeg', 'vardhaman college', 'chandankalyani.c@gmail.com'),
(2, 'ketan', 'ketan college of engineering', 'ketanpokar9@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `male` int(11) NOT NULL,
  `female` int(11) NOT NULL,
  `first` int(11) NOT NULL,
  `first_male` int(11) NOT NULL,
  `first_female` int(11) NOT NULL,
  `second` int(11) NOT NULL,
  `second_male` int(11) NOT NULL,
  `second_female` int(11) NOT NULL,
  `third` int(11) NOT NULL,
  `third_male` int(11) NOT NULL,
  `third_female` int(11) NOT NULL,
  `fourth` int(11) NOT NULL,
  `fourth_male` int(11) NOT NULL,
  `fourth_female` int(11) NOT NULL,
  `college_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `district_college`
--

CREATE TABLE `district_college` (
  `districtname` varchar(255) NOT NULL,
  `collegename` varchar(255) NOT NULL,
  `collegecode` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district_college`
--

INSERT INTO `district_college` (`districtname`, `collegename`, `collegecode`) VALUES
('District', 'College name', 'college code'),
('Adilabad', 'AIZZA COLLEGE OF ENGG AND TECHNOLOGY', 'AIZA'),
('Adilabad', 'AMR INSTITUTE OF TECHNOLOGY', 'AMRT'),
('HYDERABAD', 'BHOJ REDDY ENGINEERING COLLEGE FOR WOMEN', 'BREW'),
('HYDERABAD', 'JNTU COLLEGE OF ENGINEERING', 'JNTH'),
('HYDERABAD', 'LORDS INSTITUTE OF ENGINEERING AND TECHNOLOGY', 'LRDS'),
('HYDERABAD', 'MATRU SRI ENGINEERING COLLEGE', 'MECS'),
('KHAMMAM', 'ADAMS ENGINEERING COLLEGE', 'ADAM'),
('KHAMMAM', 'KAKATIYA UNIVERSITY COLLEGE OF ENGINEERING', 'KUCE'),
('KHAMMAM', 'KLR COLLEGE OF ENGINEERING AND TECHNOLOGY', 'KLRT'),
('KARIMNAGAR', 'JNTU COLLEGE OF ENGINEERING', 'JNTR'),
('KARIMNAGAR', 'KAMALA INSTITUTE OF TECHNOLGY AND SCIENCE', 'KTKM'),
('KARIMNAGAR', 'NIGAMA ENGINEERING COLLEGE', 'NGMA'),
('MAHABOOBNAGAR', 'CYBDERABAD INSTITUTE OF TECHNOLOGY', 'CITC'),
('MAHABOOBNAGAR', 'GAYATRI INSTITUTE OF TECHNOLOGY AND SCIENCE', 'GTSR'),
('MAHABOOBNAGAR', 'NOOR COLLEGE OF ENGINEERING AND TECHNOLOGY', 'NOOR'),
('MEDAK', 'COLLEGE OF ARGRICULTURAL ENGINEERING', 'CASR'),
('MEDAK', 'GOPAL REDDY COLLEGE OF ENGINEERING AND TECHNOLOGY', 'GCET'),
('MEDAK', 'MAHESHWARA ENGINEERING COLLEGE', 'MECP'),
('RANGA REDDY', 'VARDHAMAN COLLEGE OF ENGINEERING', 'VMEG'),
('RANGA REDDY', 'ANURAG COLLEGE OF ENGINEERING', 'ANRH'),
('RANGA REDDY', 'VIDYA JYOTHI INSTITUTE OF TECHNOLOGY', 'VDJM'),
('NALGONDA', 'ANURAG ENGINEERING COLLEGE', 'ANRK'),
('NALGONDA', 'GSR GROUP OF INSITUTIONS', 'GSRI'),
('NALGONDA', 'KBR ENGINEERING COLLEGE', 'KBRB'),
('NIZAMABAD', 'SRINIVAS REDDY INSTITUTE OF TECHNOLOGY', 'SNRJ'),
('NIZAMABAD', 'VIJAY COLLEGE OF ENGINEERING FOR WOMEN', 'VCEW'),
('NIZAMABAD', 'KAMAREDDY ENGINEERING COLLEGE', 'KREC'),
('WARANGAL', 'BALAJ INSTT. OF ENGINEERING AND TECHNOLOGY', 'BISN'),
('WARANGAL', 'CHAITANYA INSTITUTE OF TECHNOLOGY AND SCIENCE ', 'CITS'),
('WARANGAL', 'GANAPATHY ENGINEERING COLLEGE', 'GNPT');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_list`
--

CREATE TABLE `faculty_list` (
  `faculty_name` varchar(255) NOT NULL,
  `college_id` varchar(20) NOT NULL,
  `phone_number` int(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `college_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `event_name` varchar(255) DEFAULT NULL,
  `event_year` varchar(255) DEFAULT NULL,
  `image1` varchar(255) DEFAULT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `college_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`event_name`, `event_year`, `image1`, `image2`, `college_id`) VALUES
('Name 1', '2018', 'gallery-lg1.jpg', '11.jpg', 'vmeg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `type` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user`, `pass`, `type`) VALUES
('admin', 'admin', 'university'),
('VDJM', '645546', 'college'),
('VMEG', 'vmeg', 'college');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `event_name` varchar(255) NOT NULL,
  `year` varchar(4) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `college_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`event_name`, `year`, `file_path`, `college_id`) VALUES
('Blood Donation', '2018', 'gallery-lg6.jpg', 'vmeg'),
('Service', '2018', 'gallery-lg5.jpg', 'vmeg'),
('Plantation', '2018', '12.jpg', 'vmeg');

-- --------------------------------------------------------

--
-- Table structure for table `ranking`
--

CREATE TABLE `ranking` (
  `s.no` int(11) NOT NULL,
  `college_id` varchar(20) NOT NULL,
  `year_of_establishment` varchar(2) NOT NULL,
  `number_of_nss_unit` varchar(2) NOT NULL,
  `number_of_activities` varchar(2) NOT NULL,
  `number_of_total_students` varchar(2) NOT NULL,
  `award_winners` varchar(2) NOT NULL,
  `number_of_special_camps` varchar(2) NOT NULL,
  `public_feedback` varchar(2) NOT NULL,
  `vc_feedback` varchar(2) NOT NULL,
  `total` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ranking`
--

INSERT INTO `ranking` (`s.no`, `college_id`, `year_of_establishment`, `number_of_nss_unit`, `number_of_activities`, `number_of_total_students`, `award_winners`, `number_of_special_camps`, `public_feedback`, `vc_feedback`, `total`) VALUES
(1, 'vmeg', '5', '6', '5', '12', '5', '7', '8', '6', '10'),
(2, 'Vasavi', '20', '10', '52', '99', '56', '12', '56', '10', '7'),
(3, 'vnr', '20', '10', '52', '99', '56', '12', '56', '10', '9');

-- --------------------------------------------------------

--
-- Table structure for table `student_list`
--

CREATE TABLE `student_list` (
  `student_name` varchar(255) NOT NULL,
  `roll_number` varchar(20) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `phone_number` int(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `caste` varchar(20) NOT NULL,
  `blood_grooup` varchar(3) NOT NULL,
  `college_name` varchar(255) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Year` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_list`
--

INSERT INTO `student_list` (`student_name`, `roll_number`, `branch`, `dob`, `phone_number`, `email`, `caste`, `blood_grooup`, `college_name`, `Gender`, `Year`) VALUES
('', '', '', '', 0, '', '', '', '', '', ''),
('chandan', '141208', 'it', 'fvfv', 2147483647, 'chandan', 'oc', 'a+', 'vmeg', '', ''),
('chandan', '14808', 'it', 'fvfv', 2147483647, 'chandan', 'oc', 'a+', 'vmeg', '', ''),
('chandan', '148811208', 'it', 'fvfv', 2147483647, 'chandan', 'oc', 'a+', 'vmeg', '', ''),
('chandan', '14881208', 'it', 'fvfv', 2147483647, 'chandan', 'oc', 'a+', 'vmeg', '', ''),
('chandan kalyani', '14881a1208', 'it', '15-05-1996', 2147483647, 'chandan@gmail.com', 'oc', 'a+', 'vmeg', 'male', 'fourth'),
('chandan', '14881a128', 'it', 'fvfv', 2147483647, 'chandan', 'oc', 'a+', 'vmeg', '', ''),
('kjkj', 'kjkjn', 'kjnkj', 'kjnkjnkjn', 812152885, 'chandan@gmail.com', 'kjnkj', 'kj', 'vmeg', 'kj', 'kjknkj');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blood`
--
ALTER TABLE `blood`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `college_details_table`
--
ALTER TABLE `college_details_table`
  ADD PRIMARY KEY (`college_id`),
  ADD KEY `sno` (`sno`);

--
-- Indexes for table `college_list`
--
ALTER TABLE `college_list`
  ADD PRIMARY KEY (`s.no`,`college_id`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`college_name`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user`);

--
-- Indexes for table `ranking`
--
ALTER TABLE `ranking`
  ADD PRIMARY KEY (`s.no`,`college_id`);

--
-- Indexes for table `student_list`
--
ALTER TABLE `student_list`
  ADD PRIMARY KEY (`roll_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blood`
--
ALTER TABLE `blood`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `college_details_table`
--
ALTER TABLE `college_details_table`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `college_list`
--
ALTER TABLE `college_list`
  MODIFY `s.no` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ranking`
--
ALTER TABLE `ranking`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
